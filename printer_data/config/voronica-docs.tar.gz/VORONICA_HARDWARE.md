# Voronica — Hardware & Software Inventory
*Update this file whenever hardware or software changes. Re-upload to the Claude Project.*
<!-- Last updated: 2026-09-01 — CANCEL_PRINT macro fix applied (PRINT_END reordered before SDCARD_RESET_FILE) -->

---

## Physical Hardware

| Component | Part | Notes |
|---|---|---|
| Frame | Voron 2.4 300mm | LDO round 4040 verticals (+50mm Z), MISUMI 2040/2020 horizontals |
| Gantry | AWD Monolith | 4-motor CoreXY |
| SBC | Raspberry Pi CM4 | Active cooling confirmed |
| Main MCU | BTT Manta M8P V2 | STM32H723, USB-CAN bridge, UUID cccdb0d58c74 |
| Toolhead board | BTT EBB36 | STM32G0B1, CAN 1Mbit, UUID 6a4c8547c5af |
| X/Y motors | LDO 42STH48-2504AH ×4 | 48V, TMC5160 SPI, sense resistor 0.075Ω |
| Z motors | Moons MS17HD6P420I ×4 | 24V, TMC2209 UART, sense resistor 0.110Ω |
| Extruder motor | LDO 36STH20-1004AHG | 24V, TMC2209 UART |
| Belts | 9mm EPDM | X and Y |
| Hotend | Dragon UHF Mini | — |
| Temp sensor | MAX31865 RTD | 100Ω/2-wire/430Ω ref, EBBCan:PA4 |
| Extruder | WWBMG + RIGDA V2 | Metal Bondtech gears, 50:6 gear ratio |
| Probe | Beacon3D RevH | USB serial, contact + proximity |
| Accelerometer | ADXL345 | On EBB36 SPI, axes_map x,z,-y |
| Rails | AirTac MGN12H Z2 (X), MGN9H Z0 (Y/Z) | 350mm except Z at 400mm |
| Part cooling fan | Generic | EBBCan:PA1 |
| Hotend fan | 3-wire tach fan | EBBCan:PA0, tach EBBCan:PB9 (2PPR) — tach reliability under investigation |
| Electronics fans | Noctua NF-A6x25 ×2 | 12V, PF7 + PF9 |
| Driver fan | Noctua NF-A4x10 | 12V, PF8 |
| Bed fans | Generic | PF6 |
| Case lighting | PWM output | PA3, 44.9Hz |
| Cameras | 2× webcam | /dev/video0 (port 8080), /dev/video2 (port 8081) via Crowsnest |
| Nevermore | Active | BT address 28:CD:C1:12:FE:E4 |

---

## BoxTurtle / AFC

| Component | Part | Notes |
|---|---|---|
| Unit | BoxTurtle 4-lane | Turtle_1 |
| AFC-Lite MCU | STM32H723 | USB serial, path: usb-Klipper_stm32h723xx_320030000551333235363331-if00 |
| Buffer | TurtleNeck v1.0 | Passive — 2× microswitches wired directly to AFC-Lite GPIO, no separate MCU |
| Connection | USB (not CAN) | Correct topology — keeps CAN bus load low |
| Lanes | 4 | — |
| afc_bowden_length | ~1920mm | PTFE 4mm OD / 2mm ID |

---

## LED Chain

| Position | Device | Color Order | Role |
|---|---|---|---|
| 1–25 | BARF HD high-density logo PCB | GRB | Logo — mounted upside down, data starts upper right |
| 26 | Nozzle neopixel pair (parallel) | GRBW | Nozzle illumination |
| 27 | Sequin pair (parallel) | GRB | Nozzle accent |

- **Pin:** EBBCan:PD3
- **chain_count:** 27
- **color_order:** `GRB×25, GRBW, GRB`
- **klipper-led_effect:** uninstalled 2026-08-26 — removed to resolve EBBCan overload crashes
- **Frame rate when reinstalled:** must stay at 8fps maximum; 12fps confirmed to crash EBBCan during Beacon contact homing

---

## Software Services — Confirmed Running

| Service | Purpose | Notes |
|---|---|---|
| Kalico (Klipper fork) | Firmware host | v2026.06.00-0-ga7e74c5c-dirty |
| Moonraker | API server | v0.10.0-20-g9008485 |
| Mainsail | Web UI | v2.17.0 |
| KlipperScreen | Touchscreen UI | v0.4.7, pinned to commit d045dfe — do not update until AFC-Klipper-Screen-Add-On fixes KlippyRest removal (KlipperScreen PR #1757) |
| AFC-Klipper-Add-On | BoxTurtle filament changer | v1.2.0 |
| AFC-Klipper-Screen-Add-On | KlipperScreen AFC panel | Installed via ~/AFC-Klipper-Screen-Add-On/install.sh |
| Crowsnest | Camera streaming | 2× ustreamer instances, ports 8080 + 8081 |
| Spoolman | Filament spool manager | Running on default port |
| Mobileraker companion | Mobile app backend | ~/mobileraker_companion/ |
| Moongate | Secure Moonraker tunnel | Binds Moonraker to 127.0.0.1:7125 — external access via nginx port 80 |
| Cloudflared | Cloudflare tunnel | Persistent outbound tunnel to Cloudflare edge, port 8443 |
| Nevermore controller | Chamber filtration BT | BT address 28:CD:C1:12:FE:E4 |
| klipper_tmc_autotune | TMC driver optimisation | v0.2.0-359-gf366d75f |
| motors-sync | AWD belt sync | V2.0.0-35-g0e59ed78 |
| Klippain-ShakeTune | Input shaper analysis | v6.0.0-0-g354ee4be |
| KAMP | Adaptive bed mesh/purge | v1.1.2-13-gb0dad8ec |
| klipper-backup | Git config backup | Auto-commits to GitHub after changes |

---

## Networking

- **Static IP:** 192.168.0.5
- **CAN bus:** 1Mbit via systemd-networkd, txqueuelen 1024 via udev rule
- **can0-up.service:** disabled — do not re-enable
- **Moongate:** Moonraker bound to 127.0.0.1:7125; external access via http://192.168.0.5 (port 80 nginx)
- **KlipperScreen:** moonraker_host = 127.0.0.1, moonraker_port = 7125
- **OrcaSlicer:** hostname = 192.168.0.5 (no port)
- **Cloudflared:** tunnel to Cloudflare edge for remote access

---

## USB Device Inventory

| Device | Connection | Notes |
|---|---|---|
| Manta M8P | USB (CAN bridge) | Carries EBBCan over CAN |
| Beacon RevH | USB serial | by-id path |
| BoxTurtle AFC-Lite | USB serial | by-id path confirmed from klippy log |
| Camera ×2 | USB | via Crowsnest ustreamer |

CM4 has single USB 2.0 controller shared across all devices. Future plan: PCIe USB card to isolate cameras; move AFC-Lite to CAN.

---

## Mod History

| Date | Change | Notes |
|---|---|---|
| 2026-09-01 | CANCEL_PRINT macro fixed | Reordered macros.cfg [gcode_macro CANCEL_PRINT]: PRINT_END now runs before SDCARD_RESET_FILE, so heaters-off/retract/park always happen even if SDCARD_RESET_FILE throws when called reentrantly from virtual_sdcard's on_error path. Applied by user; not yet exercised by a real on_error abort. |
| 2026-08-31 | klippy.log forensics on 18:30–19:05 session | Full session read (not just journalctl) found the actual print-halting fault: repeated "Endstop y still triggered after retract" during G28 homing, NOT a Pi/USB freeze. See Known Issues. |
| 2026-08-26 | KlipperScreen pinned to d045dfe | KlipperScreen PR #1757 removed KlippyRest, breaking AFC panel — pinned to pre-removal commit |
| 2026-08-26 | klipper-led_effect uninstalled | Removed to resolve EBBCan overload → Timer too close crash at 12fps during Beacon contact homing |
| 2026-08-26 | Persistent journald enabled | /var/log/journal created for post-freeze forensics |
| 2026-08-26 | fan_tach_monitor max_consecutive_stops raised | Reduce false-positive fan stoppage triggers from intermittent tach signal |
| 2026-08-26 | Moongate installed | Binds Moonraker to localhost; KlipperScreen and OrcaSlicer updated accordingly |
| 2026-08-15 | AFC-Klipper-Screen-Add-On installed | KlipperScreen AFC panel via ArmoredTurtle installer |
| 2026-06-30 | BoxTurtle AFC system installed | AFC-Lite (STM32H723) USB; TurtleNeck v1.0 passive buffer |
| 2026-06-30 | CAN networking moved to systemd-networkd | FIRMWARE_RESTART recovery via udev rule; can0-up.service disabled |
| 2026-06-30 | LED config corrected | BARF HD 25× GRB; nozzle GRBW+GRB sequin (parallel pairs) |
| 2026-06-30 | Nevermore confirmed active | BT address 28:CD:C1:12:FE:E4 |
| unknown | Monolith AWD gantry | Replaced standard 2-motor gantry |
| unknown | 48V PSU for X/Y | TMC5160 at 48V, 2.5A |
| unknown | EBB36 toolhead board | CAN toolhead |
| unknown | Beacon3D RevH | Replaced previous probe |
| unknown | Dragon UHF Mini | Flow rate upgrade |
| unknown | WWBMG + RIGDA V2 | Extruder upgrade |

---

## Known Issues / Open Items

| Issue | Status | Notes |
|---|---|---|
| CANCEL_PRINT macro fails when triggered by virtual_sdcard on_error mid-print | Applied, awaiting real-world confirmation | Fixed 2026-09-01: reordered CANCEL_PRINT so PRINT_END runs before SDCARD_RESET_FILE — cooldown/park now happen even if SDCARD_RESET_FILE throws on the reentrant on_error call. Not yet verified against an actual on_error abort in the field; move to Resolved once confirmed. |
| Y-axis homing fault: "Endstop y still triggered after retract" | Open — root cause not yet identified, deprioritized | Confirmed 4× in klippy.log session spanning 18:31:39–19:04:58 on 08/31/26 (2 during print attempts, 2+ on manual re-home). Did NOT recur in the next session (19:04:59+ homed clean); no recurrence since per user (08/31/26). stepper_y: endstop_pin ^PF3 (Manta M8P, mechanical switch), homing_speed 200mm/s, homing_retract_dist 5mm (no override for homing_retract_speed/second_homing_speed — Klipper defaults apply), per steppers.cfg. Immediately preceded by a TMC5160 GSTAT reset+uv_cp(Undervoltage) event on all 4 AWD X/Y drivers simultaneously in the same log window — possible correlated power-quality event, unconfirmed. Physical switch original/unchanged per user; not physically inspected. User chose not to actively investigate further for now. |
| Camera/USB kernel errors on 08/31 boot (uvcvideo -71/-110, klipper_mcu EAGAIN write) | Resolved / not the cause | Investigated via journalctl for the 08/31 18:30 boot. Confirmed via klippy.log that Klipper's own MCU/EBBCan/beacon transport stats stayed clean (zero bytes_invalid, zero retransmits) throughout — these were kernel-level USB noise from the camera's UVC link, not related to the actual print failure (see Y-axis homing fault above). crowsnest's separate "list_libcameras Error 255" line is unrelated cosmetic noise (fires every boot, self-recovers, camera streams fine — no CSI camera present, only the USB UVC Arducam). |
| KlipperScreen pinned to d045dfe | Open | Unpin once AFC-Klipper-Screen-Add-On updates AFC.py to not import KlippyRest |
| klipper-led_effect uninstalled | Open | Reinstall once frame rate confirmed ≤8fps; breathing effects need ≥0.20 static floor |
| Hotend fan tach intermittent | Under investigation | EBBCan:PB9 produced 5 consecutive zero-RPM readings; fan visually spinning and showing RPM in Mainsail; max_consecutive_stops raised as mitigation |
| Extruder TMC2209 running hot | Open | Consider changing autotune tuning_goal from performance to auto |
| BoxTurtle PSU | Open | Requires dedicated 24V PSU >3.2A; UC-LGY-24V (3A) confirmed insufficient |
| AFC-Lite on USB | Planned | Move to CAN when USB bandwidth becomes bottleneck; frees USB slot |
| Single unexplained freeze | Open | 2026-08-26, no log evidence — persistent journal now enabled for next occurrence. NOT confirmed to be the same issue as the 08/31 Y-endstop fault above (different symptom: that one was a full freeze with no log evidence; 08/31 had full log evidence and was a homing CommandError, not a freeze). |
| Dragon Dinghy CAN bridge | Unverified | Product page claims USB-to-CAN bridge; STM32F072 may lack Klipper CAN bridge support — confirm before relying on this feature |

# Klipper Bed Mesh Guide
*Source: klipper3d.org/Bed_Mesh.html — Full official documentation*

---

## Overview

Bed Mesh compensates for bed surface irregularities to achieve a better first layer. It approximates the shape of the bed — it cannot fix mechanical or electrical issues. Probe Z-Offset must be calibrated before running BED_MESH_CALIBRATE.

---

## Basic Configuration (Rectangular Bed)

```
[bed_mesh]
speed: 120                    # speed between probe points (default 50)
horizontal_move_z: 5          # Z height while traveling between points (default 5)
mesh_min: 35, 6               # REQUIRED — first probe point, nearest to origin (relative to PROBE location)
mesh_max: 240, 198            # REQUIRED — probe point farthest from origin (relative to PROBE location)
probe_count: 5, 3             # points per axis (default 3,3). Single value applies to both. Min 3 per axis.
```

**Voronica values:**
```
mesh_min: 60, 40
mesh_max: 260, 260
probe_count: 30, 30
algorithm: bicubic
zero_reference_position: 150, 150
```

---

## Advanced Configuration

### Mesh Interpolation
```
mesh_pps: 2, 2        # interpolated points per segment per axis (default 2,2). 0 = disable interpolation.
algorithm: bicubic    # lagrange (up to 6×6 grid) or bicubic (larger grids, requires ≥4 points per axis)
bicubic_tension: 0.2  # curvature amount for bicubic (default 0.2). Higher = more slope.
```

Bicubic requires minimum 4 probed points per axis; if fewer, lagrange is forced.

### Move Splitting
Bed mesh intercepts long moves and splits them to follow bed shape:
```
move_check_distance: 5   # min distance to check Z deviation before splitting (default 5mm)
split_delta_z: .025      # min Z deviation to trigger split (default 0.025mm)
```

### Mesh Fade
Phases out Z adjustment over height range. Disabled by default (fade_end: 0).
```
fade_start: 1.0    # Z height to start phasing out adjustment (default 1.0)
fade_end: 10.0     # Z height where fade completes; 0 = disabled (default 0)
fade_target: 0     # additional Z offset after fade completes (default = mesh average)
```
**Warning:** Do not enable fade if bed is severely warped — can cause visible artifacts. If enabled, 10mm for fade_end is a good starting value.

### Zero Reference Position
Offsets the mesh so Z=0 at a specific position. Use when probe drift or temperature effects make Z offset calculation challenging.
```
zero_reference_position: 150, 150
```
Should match position where Z calibration was performed (home_xy_position for Beacon). If position is outside mesh, it will be probed separately and used as Z offset.

**Note:** As of Klipper 20230619, the old `relative_reference_index` option is removed — use `zero_reference_position` instead.

### Faulty Regions
For beds with integrated magnets or similar that cause inaccurate probe readings at specific locations. Bed mesh will probe up to 4 points at region boundaries and average them.
```
faulty_region_1_min: 130.0, 0.0
faulty_region_1_max: 145.0, 40.0
faulty_region_2_min: 225.0, 0.0
faulty_region_2_max: 250.0, 25.0
# Up to 99 faulty regions. Regions may not overlap.
```

### Adaptive Meshes
Limits mesh to the area used by objects being printed. Scales probe count proportionally. Use with KAMP or [exclude_object].
```
adaptive_margin: 5    # margin in mm around print area (default 0)
```
Usage: `BED_MESH_CALIBRATE ADAPTIVE=1`

Adaptive meshes should NOT be saved as reusable profiles — generate fresh for each print.

---

## Surface Scanning (Beacon/Eddy current probes)

Beacon supports scan mode — continuous movement without lifting between points.

Scan height set by `horizontal_move_z`. Recommended 2mm for Beacon.
Results invalid if probe is >4mm above surface.

```
BED_MESH_CALIBRATE METHOD=beacon       # standard scan
BED_MESH_CALIBRATE METHOD=rapid_scan   # faster but slightly less accurate
```

---

## G-Code Commands

### Calibration
```
BED_MESH_CALIBRATE [PROFILE=<name>] [METHOD=manual|beacon|rapid_scan] 
    [HORIZONTAL_MOVE_Z=<value>] [ADAPTIVE=1] [ADAPTIVE_MARGIN=<value>]
    [<probe_parameter>=<value>] [<mesh_parameter>=<value>]
```
After calibration, mesh is immediately active. Saved to 'default' profile unless PROFILE specified.

### Profile Management
```
BED_MESH_PROFILE LOAD=<name>           # load a saved profile
BED_MESH_PROFILE SAVE=<name>           # save current mesh to profile (requires SAVE_CONFIG to persist)
BED_MESH_PROFILE REMOVE=<name>         # delete profile (requires SAVE_CONFIG to persist)
```

**Note:** As of Klipper 20230201, bed_mesh no longer auto-loads 'default' profile on startup. Add `BED_MESH_PROFILE LOAD=default` to START_PRINT macro if needed. For Beacon, this is handled differently — contact probing recalibrates each print.

### Output and Status
```
BED_MESH_OUTPUT [PGP=[0|1]]     # print current mesh values to console
BED_MESH_MAP                    # output mesh as JSON (for visualization plugins)
BED_MESH_CLEAR                  # clear mesh, remove all Z adjustment
BED_MESH_OFFSET [X=<>] [Y=<>] [ZFADE=<>]   # apply XY offsets to mesh
```

---

## Status Variables
```
printer.bed_mesh.profile_name      # name of active profile
printer.bed_mesh.mesh_min          # active mesh min coordinates
printer.bed_mesh.mesh_max          # active mesh max coordinates
printer.bed_mesh.probed_matrix     # raw probed Z values
printer.bed_mesh.mesh_matrix       # interpolated mesh values
printer.bed_mesh.profiles          # dict of all saved profiles
```

# Klipper Resonance Compensation (Input Shaper) Guide
*Source: klipper3d.org/Resonance_Compensation.html — Full official documentation*

---

## What It Does

Input Shaping reduces ringing (echoing/ghosting/rippling) — surface defects where elements like edges repeat as a subtle echo. Ringing is caused by mechanical vibrations from quick direction changes.

**Fix mechanical issues first:** insufficiently rigid frame, loose/springy belts, misaligned parts, heavy moving mass. Input shaping compensates for vibration but cannot fix mechanical problems.

---

## Tuning — Manual Method (without accelerometer)

### Step 1: Print the ringing tower
File: docs/prints/ringing_tower.stl

Slicer settings:
- Layer height: 0.2 or 0.25mm
- Infill: 0, top layers: 0
- 1-2 perimeters or vase mode with 1-2mm base
- External perimeter speed: ~80-100mm/s
- Minimum layer time: ≤3 seconds
- Disable "dynamic acceleration control" in slicer
- Do NOT rotate the model — X/Y marks at back are reference

### Step 2: Prepare for test
```
SET_VELOCITY_LIMIT MINIMUM_CRUISE_RATIO=0
SET_PRESSURE_ADVANCE ADVANCE=0
SET_INPUT_SHAPER SHAPER_FREQ_X=0 SHAPER_FREQ_Y=0   # if input_shaper section exists
TUNING_TOWER COMMAND=SET_VELOCITY_LIMIT PARAMETER=ACCEL START=1500 STEP_DELTA=500 STEP_HEIGHT=5
```

### Step 3: Measure ringing frequency
After printing, measure distance D (mm) between N oscillations on the X-mark side:
```
frequency = V * N / D   (Hz)
```
Where V = external perimeter speed (mm/s)

Example: 100mm/s speed, 6 oscillations, 12.14mm distance → 100 × 6 / 12.14 ≈ 49.4 Hz

Repeat for Y mark to get Y frequency.

**Note:** If ringing pattern doesn't follow curved notches, the defect has a different origin (mechanical or extruder). Fix that first.

### Step 4: Add to config
```
[input_shaper]
shaper_freq_x: 49.4
shaper_freq_y: 49.4   # use your measured values
shaper_type: mzv
```

---

## Choosing Input Shaper Type

**Supported shapers:** `zv`, `mzv`, `zvd`, `ei`, `2hump_ei`, `3hump_ei`

### Testing procedure
1. `RESTART`
2. `SET_VELOCITY_LIMIT MINIMUM_CRUISE_RATIO=0`
3. `SET_PRESSURE_ADVANCE ADVANCE=0`
4. `SET_INPUT_SHAPER SHAPER_TYPE=MZV`
5. `TUNING_TOWER COMMAND=SET_VELOCITY_LIMIT PARAMETER=ACCEL START=1500 STEP_DELTA=500 STEP_HEIGHT=5`
6. Print test model

If no ringing: use MZV.
If ringing still visible: try EI (`SET_INPUT_SHAPER SHAPER_TYPE=EI`).

**Choose MZV if:** results are similar — MZV causes less smoothing.
**Choose EI if:** clearly better results, OR bed-slinger printer (EI more robust to mass changes), OR delta printer.

### Selection guidance by scenario
| Frequency | Recommendation |
|---|---|
| >50-60 Hz | Can try 2HUMP_EI, or MZV/EI |
| 25-50 Hz | MZV preferred, EI if needed |
| <25 Hz | ZV (least smoothing), or stiffen printer |
| Very low (<20 Hz) | Prioritize mechanical improvements |

---

## Selecting max_accel

After choosing shaper type, find max_accel by inspecting the test print for two limits:

1. **Ringing limit:** acceleration where ringing becomes unacceptable
2. **Smoothing limit:** acceleration where the 0.15mm gap in the test model starts to widen

Choose the MINIMUM of these two values as max_accel.

**Note:** Do not increase `square_corner_velocity` above 5mm/s to avoid increased smoothing.

---

## Troubleshooting and FAQ

**Q: Cannot get reliable ringing frequency measurements?**
The printer may have multiple resonance frequencies on one axis, or the issue is not ringing. Consider using an accelerometer for auto-calibration.

**Q: After enabling input_shaper, parts are too smooth?**
- Resonance frequency is low — do not set high max_accel
- Try MZV instead of EI, or ZV instead of MZV
- Do not increase square_corner_velocity

**Q: Ringing came back after printing fine for a while?**
Resonance frequencies change when belts loosen, hardware changes, or mass changes. Re-measure and update config.

**Q: Does input_shaper affect print time?**
No. Input shaping does not change toolhead path, timing, or total filament extruded.

**Q: Should I tune Z axis input shaper?**
Generally not recommended unless Z experiences significant ringing. Z resonance frequency is typically much lower and shaping it has limited benefit.

---

## Re-tuning When Needed

Re-run IS calibration whenever:
- Motor or hotend replaced (mass change)
- Belts retightened or replaced
- Frame rigidity addons installed
- Different bed installed
- Any other hardware change affecting moving mass or stiffness

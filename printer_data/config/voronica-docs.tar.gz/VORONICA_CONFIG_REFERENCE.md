# Voronica — Klipper/Kalico Config & Command Reference
*Grounded in confirmed working config and verified Klipper/Kalico docs*
*Do not invent keys, parameters, or commands not listed here — fetch live docs instead*

---

## How to Use This File

This is a hard reference for config section keys and runtime commands relevant to this printer. Every entry is sourced from either:
- **(W)** — Confirmed working in Voronica's actual config files
- **(D)** — Verified from official Klipper/Kalico documentation

If a key or command is not listed here and not found in live docs, it does not exist. Do not guess.

---

## Config Section Reference

### [printer]
```
[printer]
kinematics: corexy          # (W)(D)
max_velocity:               # mm/s (W) current: 2000
max_accel:                  # mm/s² (W) current: 50000
max_z_velocity:             # mm/s (W) current: 100
max_z_accel:                # mm/s² (W) current: 500
square_corner_velocity:     # mm/s (W) current: 16
minimum_cruise_ratio:       # 0.0–1.0, replaces accel_to_decel (D) Kalico uses this
```
**Note:** `accel_to_decel` / `max_accel_to_decel` are deprecated. Kalico uses `minimum_cruise_ratio`. Do not suggest `max_accel_to_decel` for this printer.

---

### [stepper_x/y/x1/y1] — TMC5160 SPI axes
```
step_pin:                   # (W)
dir_pin:                    # (W) inverted with !
enable_pin:                 # (W) inverted with !
microsteps: 32              # (W)
rotation_distance: 40       # (W)
full_steps_per_rotation: 200 # (W) 1.8° motors
endstop_pin:                # (W) stepper_x uses EBBCan:PB8, stepper_y uses ^PF3
position_min:               # (W) X: 0, Y: -5
position_endstop:           # (W) X: 295.5, Y: 305
position_max:               # (W) X: 295.5, Y: 305
homing_speed: 200           # (W)
homing_retract_dist: 5      # (W)
homing_positive_dir: true   # (W)
```

### [tmc5160 stepper_x/y/x1/y1]
```
cs_pin:                     # (W) SPI chip select
spi_software_sclk_pin: PG8  # (W)
spi_software_mosi_pin: PG6  # (W)
spi_software_miso_pin: PG7  # (W)
run_current: 2.5            # (W) amps
sense_resistor: 0.075       # (W) TMC5160 value — do NOT use 0.110 (that's TMC2209)
interpolate: true           # (W)
stealthchop_threshold: 0    # (W) 0 = spreadcycle always
```
**Note:** TMC5160 uses SPI, not UART. `uart_pin` is wrong for these drivers. `sense_resistor` is 0.075, not 0.110.

---

### [stepper_z/z1/z2/z3] — TMC2209 UART axes
```
step_pin:                   # (W)
dir_pin:                    # (W) z1 and z3 inverted with !
enable_pin:                 # (W) inverted with !
rotation_distance: 40       # (W)
gear_ratio: 80:16           # (W)
microsteps: 16              # (W)
endstop_pin: probe:z_virtual_endstop  # (W) Beacon virtual endstop
position_max: 275           # (W)
position_min: -1.0          # (W)
homing_speed: 50            # (W)
second_homing_speed: 10     # (W)
homing_retract_dist: 0      # (W) 0 required for Beacon contact homing
```

### [tmc2209 stepper_z/z1/z2/z3]
```
uart_pin:                   # (W)
interpolate: true           # (W)
run_current: 0.8            # (W)
sense_resistor: 0.110       # (W) TMC2209 value
stealthchop_threshold: 999999  # (W) stealthchop always on for Z
```

---

### [extruder]
```
step_pin: EBBCan:PD0        # (W)
dir_pin: !EBBCan:PD1        # (W) inverted
enable_pin: !EBBCan:PD2     # (W) inverted
full_steps_per_rotation: 200 # (W)
microsteps: 16              # (W)
gear_ratio: 50:6            # (W)
rotation_distance: 22.6789511  # (W)
nozzle_diameter: 0.400      # (W)
filament_diameter: 1.750    # (W)
heater_pin: EBBCan:PB13     # (W)
sensor_type: MAX31865        # (W)
sensor_pin: EBBCan:PA4      # (W)
spi_bus: spi1               # (W)
rtd_nominal_r: 100          # (W)
rtd_reference_r: 430        # (W)
rtd_num_of_wires: 2         # (W)
min_temp: 0                 # (W)
max_temp: 500               # (W)
min_extrude_temp: 170       # (W)
max_extrude_cross_section: 5  # (W)
max_extrude_only_distance: 150  # (W)
pressure_advance:           # (D) set per material — currently not set in config
pressure_advance_smooth_time: 0.040  # (W)
```

### [tmc2209 extruder]
```
uart_pin: EBBCan:PA15       # (W)
run_current: 0.7            # (W)
sense_resistor: 0.110       # (W)
stealthchop_threshold: 999999  # (W)
```

---

### [autotune_tmc] — klipper_tmc_autotune plugin
```
[autotune_tmc stepper_x]
motor: ldo-42sth48-2504ah   # (W) must match motor DB entry exactly
tuning_goal: performance    # (W) options: auto, silent, performance
voltage: 48                 # (W) supply voltage in volts
```
**Valid motor DB names for this printer:**
- `ldo-42sth48-2504ah` — X/Y motors
- `moons-ms17hd6p420i` — Z motors
- `ldo-36sth20-1004ahg` — extruder motor

**Note:** Motor names must match the autotune motor database exactly. Do not guess or abbreviate. Check https://github.com/andrewmcgr/klipper_tmc_autotune/tree/main/motor_database for valid entries.

---

### [beacon]
```
[beacon]
serial:                     # (W) /dev/serial/by-id/usb-Beacon_Beacon_RevH_...
speed: 5                    # (W) Z dive speed mm/s
lift_speed: 5               # (W) Z lift speed mm/s
x_offset: 0                 # (W)
y_offset: 23                # (W) Beacon is 23mm behind nozzle
mesh_main_direction: x      # (W)
mesh_runs: 1                # (W)
backlash_comp: 0.06         # (W) confirmed working value
contact_max_hotend_temperature: 180  # (W) increase to probe at print temps
home_xy_position: 150, 150  # (W)
home_z_hop: 5               # (W)
home_z_hop_speed: 50        # (W)
home_xy_move_speed: 500     # (W)
home_y_before_x: True       # (W)
home_method: contact        # (W) initial home uses contact
home_method_when_homed: proximity  # (W) subsequent homing uses proximity
home_autocalibrate: unhomed # (W) contact calibrates on first home only
is_non_critical: True       # (W)
accel_axes_map: -x, -y, z  # (W)
```

**Beacon G-code commands (verified):**
```
BEACON_CALIBRATE           # Manual contact calibration
BEACON_AUTO_CALIBRATE      # Automated contact calibration
BEACON_QUERY               # Query beacon status/signal
PROBE_ACCURACY             # Test probe repeatability
BEACON_ESTIMATE_BACKLASH   # Estimate backlash compensation value
G28 Z METHOD=CONTACT CALIBRATE=1   # Home Z with contact + calibrate model
G28 Z METHOD=CONTACT CALIBRATE=0   # Home Z with contact, skip model cal
G28 Z METHOD=PROXIMITY             # Home Z with proximity (fast)
BED_MESH_CALIBRATE ADAPTIVE=1      # Adaptive mesh scan
BED_MESH_CALIBRATE RUNS=1 ADAPTIVE=1  # (W) as used in PRINT_START
```

---

### [input_shaper]
```
[input_shaper]
shaper_freq_x: 107.2        # (W) Hz
shaper_type_x: mzv          # (W)
damping_ratio_x: 0.068      # (W) — Kalico/Danger Klipper feature
shaper_freq_y: 82.6         # (W)
shaper_type_y: mzv          # (W)
damping_ratio_y: 0.072      # (W)
```
**Valid shaper types (D):** `zv`, `mzv`, `zvd`, `ei`, `2hump_ei`, `3hump_ei`
**Note:** `damping_ratio_x/y` is a Kalico extension — not available in standard Klipper. Do not suggest it for non-Kalico installs.

---

### [motors_sync] — motors-sync plugin
```
[motors_sync]
axes: x,y                   # (W)
accel_chip: adxl345         # (W)
```
**Runtime command:**
```
SYNC_MOTORS                 # Run AWD belt synchronisation
```
**Note:** The phase offsets (x=384, y=-240) are saved to variables.cfg automatically after sync — do not suggest manually editing them.

---

### [bed_mesh]
```
[bed_mesh]
zero_reference_position: 150, 150  # (W)
speed: 300                  # (W)
mesh_min: 60, 40            # (W)
mesh_max: 260, 260          # (W)
probe_count: 30, 30         # (W)
algorithm: bicubic          # (W)
```
**Runtime commands:**
```
BED_MESH_CALIBRATE          # Run mesh
BED_MESH_CALIBRATE ADAPTIVE=1  # KAMP adaptive mesh
BED_MESH_CLEAR              # Clear active mesh
BED_MESH_PROFILE LOAD=<name>   # Load saved profile
BED_MESH_PROFILE SAVE=<name>   # Save current mesh
```

---

### [quad_gantry_level]
```
[quad_gantry_level]
gantry_corners:
    -60,-10
    360,370
points:
    50,25
    50,225
    250,225
    250,25
speed: 500                  # (W)
horizontal_move_z: 3        # (W)
retries: 20                 # (W)
retry_tolerance: 0.0075     # (W)
max_adjust: 10              # (W)
```
**Runtime command:**
```
QUAD_GANTRY_LEVEL           # (W) overridden macro — runs coarse+fine on cold, fine-only on warm
_QUAD_GANTRY_LEVEL          # underlying command, accepts all standard params
QUAD_GANTRY_LEVEL HORIZONTAL_MOVE_Z=10.0 RETRY_TOLERANCE=1.0  # coarse pass
QUAD_GANTRY_LEVEL HORIZONTAL_MOVE_Z=3.0 RETRY_TOLERANCE=0.0075  # fine pass
```

---

### [heater_bed]
```
[heater_bed]
heater_pin: PA1             # (W)
sensor_pin: PB1             # (W)
sensor_type: Generic 3950   # (W)
max_power: 1.0              # (W)
min_temp: 0                 # (W)
max_temp: 130               # (W)
```

---

### [fan] / [heater_fan] / [controller_fan] / [fan_generic]
```
# Part cooling
[fan]
pin: EBBCan:PA1             # (W)
cycle_time: 0.01            # (W) 100Hz
kick_start_time: 0.100      # (W)

# Hotend fan
[heater_fan hotend_fan]
pin: EBBCan:PA0             # (W)
heater: extruder            # (W)
heater_temp: 50.0           # (W)
fan_speed: 1.0              # (W)
tachometer_pin: ^EBBCan:PB9 # (W) pullup required
tachometer_ppr: 2           # (W)
tachometer_poll_interval: 0.00004  # (W)

# Bed fans
[fan_generic BedFans]
pin: PF6                    # (W)
cycle_time: 0.05            # (W)
kick_start_time: 0.5        # (W)
```
**Runtime commands:**
```
SET_FAN_SPEED FAN=<name> SPEED=<0.0-1.0>   # (D)
M106 S<0-255>              # Part cooling fan speed
M107                       # Part cooling fan off
```

---

### [firmware_retraction]
```
[firmware_retraction]
retract_length: 0.4         # (W) mm
retract_speed: 40           # (W) mm/s
unretract_extra_length: 0   # (W)
unretract_speed: 35         # (W) mm/s
```
**Runtime commands:**
```
SET_RETRACTION [RETRACT_LENGTH=<mm>] [RETRACT_SPEED=<mm/s>] [UNRETRACT_SPEED=<mm/s>]
GET_RETRACTION
G10                         # Retract (requires firmware_retraction)
G11                         # Unretract
```

---

### [shaketune] — Klippain ShakeTune
```
[shaketune]
result_folder: ~/printer_data/config/ShakeTune_results  # (W)
number_of_results_to_keep: 1000  # (W)
keep_raw_data: False        # (W)
show_macros_in_webui: True  # (W)
timeout: 600                # (W)
measurements_chunk_size: 2  # (W)
max_freq: 200               # (W)
dpi: 300                    # (W)
```
**ShakeTune G-code commands (verified):**
```
AXES_SHAPER_CALIBRATION     # Full input shaper calibration with graphs
BELT_TENSION_CALIBRATION    # Belt comparison/tension check (replaces older COMPARE_BELTS_RESPONSES)
COMPARE_BELTS_RESPONSES     # Belt comparison (older name, may still work)
CREATE_VIBRATIONS_PROFILE   # Full vibration profile
EXCITATE_AXIS_AT_FREQ AXIS=<x/y> FREQ=<hz>  # Excite at specific frequency
AXES_MAP_CALIBRATION        # Accelerometer axes mapping
```
**Note:** ShakeTune macro names change between versions. If a command errors, fetch the current macro list from https://github.com/Frix-x/klippain-shaketune/wiki

---

## Runtime Command Reference

### Motion & Homing
```
G28                         # Home all (uses homing_override — Y→X→center→Z)
G28 X                       # Home X only (requires Y homed first)
G28 Y                       # Home Y
G28 Z                       # Home Z (requires XY homed, moves to center first)
G28 Z METHOD=CONTACT CALIBRATE=1   # Beacon contact home + model calibration
G28 Z METHOD=CONTACT CALIBRATE=0   # Beacon contact home only
G90                         # Absolute positioning
G91                         # Relative positioning
G92 E0                      # Reset extruder position
G1 X<> Y<> Z<> F<>         # Move (F in mm/min — multiply mm/s by 60)
G0 X<> Y<> F<>             # Rapid move
M400                        # Wait for moves to complete
```

### Velocity & Limits
```
SET_VELOCITY_LIMIT VELOCITY=<> ACCEL=<> MINIMUM_CRUISE_RATIO=<>  # (D) Kalico
SET_VELOCITY_LIMIT VELOCITY=<> ACCEL=<> SQUARE_CORNER_VELOCITY=<>
```
**Note:** Do NOT use `ACCEL_TO_DECEL` parameter — deprecated. Use `MINIMUM_CRUISE_RATIO`.

### Temperature
```
M104 S<temp>               # Set hotend temp (no wait)
M109 S<temp>               # Set hotend temp and wait (overridden macro — waits within 1°C)
M140 S<temp>               # Set bed temp (no wait, overridden — triggers bed fan logic)
M190 S<temp>               # Set bed temp and wait (overridden — triggers bed fan logic)
TEMPERATURE_WAIT SENSOR=<name> MINIMUM=<> MAXIMUM=<>  # Wait for temp range
TURN_OFF_HEATERS           # All heaters off (overridden — also turns off bed fans)
PID_CALIBRATE HEATER=<name> TARGET=<temp>  # PID autotune
SAVE_CONFIG                # Save PID results (and other auto-generated values) to printer.cfg
```

### TMC Drivers
```
DUMP_TMC STEPPER=<name>    # Dump all TMC registers
SET_TMC_CURRENT STEPPER=<name> CURRENT=<amps>  # Set run current at runtime
AUTOTUNE_TMC STEPPER=<name>  # Re-run autotune for one stepper (autotune plugin)
```
**Note for TMC5160:** After `SET_TMC_CURRENT`, if stealthchop is enabled, hold stepper at standstill for >130ms for AT#1 calibration. Not applicable here (stealthchop OFF on XY).

### Pressure Advance
```
SET_PRESSURE_ADVANCE ADVANCE=<value> [EXTRUDER=<name>] [SMOOTH_TIME=<seconds>]
```

### Z Offset
```
SET_GCODE_OFFSET Z=<value>         # Set absolute Z offset
SET_GCODE_OFFSET Z_ADJUST=<value>  # Adjust Z offset by delta
SET_GCODE_OFFSET Z=0               # Reset Z offset
```

### Bed Mesh
```
BED_MESH_CALIBRATE              # Run mesh (uses Beacon proximity scan)
BED_MESH_CALIBRATE ADAPTIVE=1   # KAMP adaptive mesh
BED_MESH_CLEAR                  # Clear mesh
BED_MESH_PROFILE LOAD=<name>
BED_MESH_PROFILE SAVE=<name>
BED_MESH_PROFILE REMOVE=<name>
```

### Diagnostics
```
STEPPER_BUZZ STEPPER=<name>     # Buzz a stepper for wiring verification
QUERY_ENDSTOPS                  # Check all endstop states
GET_POSITION                    # Report current MCU stepper positions
ACCELEROMETER_QUERY CHIP=<name> # Test accelerometer (adxl345 or beacon)
MEASURE_AXES_NOISE CHIP=<name>  # Measure accelerometer noise floor
TEST_RESONANCES AXIS=<X/Y> [CHIP=<name>]  # Raw resonance sweep
PROBE_ACCURACY                  # Beacon probe repeatability test
```

### Macros Defined on This Printer
```
PRINT_START BED=<> EXTRUDER=<> [CHAMBER=<>] [FILAMENT_PROFILE=<>] [BED_TYPE=<>]
PRINT_END
QUAD_GANTRY_LEVEL           # Custom — coarse+fine logic
PAUSE [Z=<zhop>]
RESUME [E=<prime_mm>]
CANCEL_PRINT
M600                        # Filament change (calls PAUSE)
G32                         # Home + QGL
_CG32                       # Conditional home + QGL (skips if already done)
SYNC_MOTORS                 # AWD belt sync
WIPE                        # 10-pass nozzle wipe
SCRUBBLER                   # CG32 + wipe + home Z
SQUIGGLY_PURGE [STEPS=<>] [PERIODS=<>] [AMPLITUDE=<>] [PURGE_LENGTH=<>] [FLOWRATE=<>]
LOAD_FILAMENT
UNLOAD_FILAMENT
PURGE                       # Simple 50mm extrude purge
UNSAFE_MOVE_TOOL X=<> Y=<> Z=<> F=<>  # Move without homing
center                      # Move to X150 Y150 after CG32
LIGHT_100                   # Case light 100%
LIGHT_OFF                   # Case light off
update_git [MESSAGE=<>]     # Trigger klipper-backup to GitHub
SET_FILAMENT_OFFSET OFFSET=<>  # Set per-filament Z offset
BELT_SET                    # AWD motion pattern for belt seating
tune_inputshaper            # CG32 + AXES_SHAPER_CALIBRATION
tune_belt_comparison        # CG32 + COMPARE_BELTS_RESPONSES
tune_vibrations             # CG32 + CREATE_VIBRATIONS_PROFILE
RESONANCE_TEST_X / RESONANCE_TEST_Y  # ResHelper resonance test + graph
```

---

## Common Mistakes to Avoid

| Wrong | Correct | Reason |
|---|---|---|
| `max_accel_to_decel` | `minimum_cruise_ratio` | Deprecated, Kalico uses new param |
| `ACCEL_TO_DECEL=` in SET_VELOCITY_LIMIT | `MINIMUM_CRUISE_RATIO=` | Same reason |
| `uart_pin` on TMC5160 | `cs_pin` + `spi_software_*` pins | TMC5160 is SPI not UART |
| `sense_resistor: 0.110` on TMC5160 | `sense_resistor: 0.075` | Different hardware value |
| `damping_ratio_x` in standard Klipper | Only valid in Kalico | Kalico extension |
| `homing_retract_dist: 5` on Z | `homing_retract_dist: 0` | Required for Beacon contact |
| `G28 Z` without XY homed | Check homed_axes first | homing_override will error |
| `SET_GCODE_OFFSET Z_ADJUST` before `SET_GCODE_OFFSET Z=0` | Reset first, then adjust | Offsets stack — reset at print start |
| Suggesting `[safe_z_home]` | Not used — `[homing_override]` handles homing | safe_z_home is commented out |
| `BED_MESH_PROFILE LOAD=default` at startup | Not needed — Beacon handles Z dynamically | Beacon contact replaces static offset |

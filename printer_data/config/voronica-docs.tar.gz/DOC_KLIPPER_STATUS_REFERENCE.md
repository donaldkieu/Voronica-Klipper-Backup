# Klipper Status Reference
*Source: klipper3d.org/Status_Reference.html — Full official documentation*
*All printer.* variables available in macros, display fields, and API*

---

## How to Access

In gcode_macro: `printer.<object>.<field>`
For objects with spaces in name: `printer["<object name>"].<field>`

Example: `printer["heater_fan hotend_fan"].rpm`

---

## bed_mesh
- `profile_name`: Name of currently active mesh profile
- `mesh_min`, `mesh_max`: Bounds of active mesh
- `probed_matrix`: Raw probed z values
- `mesh_matrix`: Interpolated mesh values
- `profiles`: Set of all defined profiles

## canbus_stats (canbus_stats <mcu_name>)
- `rx_error`: Receive errors detected by MCU CAN hardware
- `tx_error`: Transmit errors
- `tx_retries`: Transmit retries due to bus contention
- `bus_state`: "active" | "warn" | "passive" | "off"

## configfile
- `settings.<section>.<option>`: Config setting value (or default) at last start/restart. NOT updated at runtime.
- `config.<section>.<option>`: Raw string value from config file
- `save_config_pending`: True if SAVE_CONFIG would write changes
- `save_config_pending_items`: Sections/options pending SAVE_CONFIG
- `warnings`: List of config warnings (each has `type` and `message`)

## display_status
- `progress`: Progress value from last M73 (or virtual_sdcard.progress if no M73)
- `message`: Message from last M117 command

## exclude_object
- `objects`: Array of known objects (name, center, polygon)
- `excluded_objects`: Array of excluded object name strings
- `current_object`: Name of object currently being printed

## extruder / extruder_stepper
- `pressure_advance`: Current PA value
- `smooth_time`: Current PA smooth time
- `motion_queue`: Name of extruder stepper is synchronized to (None if not associated)
- `temperature`: Current temperature (°C)
- `target`: Target temperature (°C)
- `power`: PWM power (0.0–1.0)
- `can_extrude`: True if hotend is hot enough to extrude

## fan / heater_fan / controller_fan
- `speed`: Fan speed (0.0–1.0)
- `rpm`: Measured RPM (only if tachometer_pin defined)

## filament_switch_sensor
- `enabled`: True if sensor is enabled
- `filament_detected`: True if sensor is triggered

## firmware_retraction
- `retract_length`, `retract_speed`, `unretract_extra_length`, `unretract_speed`: Current retraction settings (may differ from config if SET_RETRACTION was used)

## gcode_macro <name>
- `<variable>`: Current value of any variable_ defined in the macro

## gcode_move
- `gcode_position`: Current toolhead position relative to current G-Code origin (what G1 commands use) — coordinate object
- `position`: Last commanded position using config coordinate system — coordinate object
- `homing_origin`: Origin of gcode coordinate system after G28. SET_GCODE_OFFSET changes this — coordinate object
- `speed`: Last speed set in G1 command (mm/s)
- `speed_factor`: Speed factor override from M220 (1.0 = no override)
- `extrude_factor`: Extrude factor override from M221 (1.0 = no override)
- `absolute_coordinates`: True if in G90 mode, False if G91
- `absolute_extrude`: True if in M82 mode, False if M83

## heater (extruder / heater_bed / heater_generic)
- `temperature`: Current temperature (°C, float)
- `target`: Target temperature (°C, float)
- `power`: PWM power (0.0–1.0)
- `can_extrude`: True if above min_extrude_temp (extruder only)

## heaters
- `available_heaters`: List of all heater section names
- `available_sensors`: List of all temperature sensor section names
- `available_monitors`: List of temperature monitors (e.g. TMC drivers with temp reporting)

## idle_timeout
- `state`: "Idle" | "Printing" | "Ready"
- `printing_time`: Seconds spent in "Printing" state
- `idle_timeout`: Current timeout value in seconds

## led / neopixel
- `color_data`: List of [R, G, B, W] lists (0.0–1.0) for each LED in chain
  - Example: `printer["neopixel sb_leds"].color_data[0][2]` → blue value of first LED

## mcu / mcu <name>
- `mcu_version`: Klipper version on MCU
- `mcu_build_versions`: Build tool info
- `mcu_constants.<name>`: Compile-time constants
- `last_stats.<name>`: MCU connection statistics

## motion_report
- `live_position`: Current interpolated toolhead position — coordinate object
- `live_velocity`: Current toolhead velocity (mm/s)
- `live_extruder_velocity`: Current extruder velocity (mm/s)

## output_pin <name>
- `value`: Current pin value (0.0–1.0 for PWM, 0 or 1 for digital)

## pause_resume
- `is_paused`: True if PAUSE executed without corresponding RESUME

## print_stats
- `filename`: Current print filename
- `total_duration`: Total time since print started (seconds)
- `print_duration`: Time spent actually printing (seconds)
- `filament_used`: Filament used (mm)
- `state`: "standby" | "printing" | "paused" | "error" | "complete"
- `message`: Current status message
- `info.total_layer`: Total layers (from SET_PRINT_STATS_INFO)
- `info.current_layer`: Current layer (from SET_PRINT_STATS_INFO)

## probe
- `name`: Name of probe in use
- `last_query`: True if probe was triggered during last QUERY_PROBE
- `last_probe_position`: X, Y, Z position of last PROBE command — coordinate object

## quad_gantry_level
- `applied`: True if QGL has been run and completed successfully this session

## query_endstops
- `last_query["<endstop>"]`: True if endstop was triggered during last QUERY_ENDSTOPS

## stepper_enable
- `steppers["<stepper>"]`: True if given stepper is enabled

## system_stats
- `sysload`: System load
- `cputime`: CPU time used by Klipper process
- `memavail`: Available memory (bytes)

## temperature_sensor <name>
- `temperature`: Last read temperature (°C)
- `measured_min_temp`: Lowest temperature since last restart
- `measured_max_temp`: Highest temperature since last restart

## tmc drivers (tmc2209 stepper_x, tmc5160 stepper_x, etc.)
- `mcu_phase_offset`: MCU stepper position at driver "zero" phase (null if unknown)
- `phase_offset_position`: Commanded position at driver "zero" phase (null if unknown)
- `drv_status`: Last driver status query results (non-zero fields only, null if driver disabled)
- `temperature`: Internal driver temperature (null if disabled or not supported)
- `run_current`: Currently set run current
- `hold_current`: Currently set hold current

## toolhead
- `position`: Last commanded toolhead position — coordinate object
- `extruder`: Name of currently active extruder (e.g. "extruder")
- `homed_axes`: String of homed axes, e.g. "xyz" or "xy" or ""
- `axis_minimum`: Axis travel minimum limits after homing — coordinate object
- `axis_maximum`: Axis travel maximum limits after homing — coordinate object
- `max_velocity`: Current max velocity limit (may differ from config if SET_VELOCITY_LIMIT used)
- `max_accel`: Current max acceleration limit
- `minimum_cruise_ratio`: Current minimum cruise ratio
- `square_corner_velocity`: Current SCV setting
- `stalls`: Number of times printer had to pause due to toolhead moving faster than gcode input

## virtual_sdcard
- `is_active`: True if printing from file
- `progress`: Estimated print progress (0.0–1.0, based on file position/size)
- `file_path`: Full path to current file
- `file_position`: Current position in file (bytes)
- `file_size`: Total file size (bytes)

## webhooks
- `state`: "ready" | "startup" | "shutdown" | "error"
- `state_message`: Human readable state description

## z_tilt
- `applied`: True if Z tilt adjustment has been run and completed successfully

---

## Accessing Coordinates

Coordinate objects have `.x`, `.y`, `.z` (and `.e` for extruder) attributes:

```
printer.toolhead.position.x      # current X
printer.toolhead.axis_maximum.z  # Z maximum
printer.gcode_move.gcode_position.z  # current gcode Z
```

---

## Common Macro Patterns Using Status

```jinja2
# Check if homed
{% if 'xyz' in printer.toolhead.homed_axes %}

# Check if QGL applied this session
{% if printer.quad_gantry_level.applied %}

# Check if paused
{% if printer['pause_resume'].is_paused|int == 0 %}

# Get extruder target temp
{% set hotend_temp = printer[printer.toolhead.extruder].target %}

# Get chamber temp
{% set chamber = printer["temperature_sensor chamber"].temperature %}

# Get fan RPM
{% set rpm = printer["heater_fan hotend_fan"].rpm %}

# Get TMC run current
{% set current = printer["tmc5160 stepper_x"].run_current %}

# Get saved variable
{% set plates = printer.save_variables.variables.plates %}

# Get config setting
{% set max_vel = printer.configfile.settings.printer.max_velocity %}

# Get macro variable
{% set zhop = printer["gcode_macro RESUME"].zhop %}

# Check print state
{% if printer.print_stats.state == "printing" %}

# Get axis limits
{% set x_center = printer.toolhead.axis_maximum.x / 2 %}
```

# Klipper Manual Leveling Guide
*Source: klipper3d.org/Manual_Level.html — Full official documentation*
*Voronica uses Beacon + QGL, not Z endstop or bed screws. Reference only — but SCREWS_TILT_CALCULATE concepts and Z_ENDSTOP_CALIBRATE may apply to the Voron 0.2 secondary printer.*

---

## Calibrating a Z Endstop (Z_ENDSTOP_CALIBRATE)
An accurate Z endstop position is critical. The endstop switch's own accuracy can be a limiting factor — with TMC drivers, consider enabling endstop phase detection to improve switch accuracy.

Procedure:
1. Home the printer, raise head ≥5mm above bed, move to XY near bed center.
2. Run `Z_ENDSTOP_CALIBRATE`.
3. Follow the paper test (TESTZ commands).
4. `ACCEPT`, then `SAVE_CONFIG`.

**Preference:** Use a Z-max endstop and home AWAY from the bed (safer — avoids bed collisions). If you must home toward the bed, position the endstop to trigger a small distance (e.g. 0.5mm) above the bed — `Z_ENDSTOP_CALIBRATE` should then report a small positive position_endstop. Most switches can safely depress slightly beyond their trigger point. This reduces bed-crash risk.

Adjust Z endstop position in software with Z_ENDSTOP_CALIBRATE or by manually editing Z position_endstop — don't rely solely on physical switch position.

---

## Adjusting Bed Leveling Screws (BED_SCREWS_ADJUST)
Leverages the printer's precision motion system. Define each screw's XY location:
```
[bed_screws]
screw1: 100, 50
screw2: 100, 150
screw3: 150, 100
```
If a screw is under the bed, specify the XY directly above it. If outside the bed, specify the closest in-range XY.

Run `RESTART`, then `BED_SCREWS_ADJUST`. The nozzle moves to each screw at Z=0. Use the paper test, but adjust the SCREW (not the nozzle height) until small friction is felt. Then:
- `ACCEPT` — no significant adjustment was needed.
- `ADJUSTED` — screw needed adjustment (>~1/8 turn). Schedules another verification cycle.
- `ABORT` — exit early.

Tool completes when all screws verify without significant adjustment. Works best with a flat surface (glass) and straight rails.

### Fine-Grained Bed Screw Adjustments
For 3 screws all under the bed: command the nozzle to positions where the bed swings further per screw adjustment (pendulum effect about the other two screws), enabling more precise correction.
```
[bed_screws]
screw1: 100, 50
screw1_fine_adjust: 0, 0
screw2: 100, 150
screw2_fine_adjust: 300, 300
screw3: 150, 100
screw3_fine_adjust: 0, 100
```
BED_SCREWS_ADJUST prompts coarse adjustments first, then fine adjustments at the additional locations.

---

## Adjusting Bed Screws Using the Bed Probe (SCREWS_TILT_CALCULATE)
Requires a Z probe. Define nozzle coordinates such that the PROBE sits above each screw:
```
[screws_tilt_adjust]
screw1: -5, 30
screw1_name: front left screw
screw2: 155, 30
screw2_name: front right screw
screw3: 155, 190
screw3_name: rear right screw
screw4: -5, 190
screw4_name: rear left screw
horizontal_move_z: 10.
speed: 50.
screw_thread: CW-M3
```
screw1 is the reference (assumed at correct height). Run `G28`, then `SCREWS_TILT_CALCULATE`. Output example:
```
// 01:20 means 1 full turn and 20 minutes, CW=clockwise, CCW=counter-clockwise
// front left screw (base) : x=-5.0, y=30.0, z=2.48750
// front right screw : z=2.36000 : adjust CW 01:15
// rear right screw : z=2.71500 : adjust CCW 00:50
// rear left screw : z=2.47250 : adjust CW 00:02
```
"Minutes" = minutes on a clock face (15 min = quarter turn). Repeat until all adjustments are below ~6 minutes.

**If the probe has an X/Y offset:** adjusting bed tilt invalidates prior probe calibration done on a tilted bed — re-run probe calibration after adjusting screws.

**MAX_DEVIATION parameter:** Useful with a saved bed mesh to ensure level hasn't drifted. E.g. `SCREWS_TILT_CALCULATE MAX_DEVIATION=0.01` in slicer start gcode before loading mesh — aborts the print if exceeded.

**DIRECTION parameter:** For screws that turn one direction only. `SCREWS_TILT_CALCULATE DIRECTION=CW` or `DIRECTION=CCW` — a suitable reference point is chosen automatically.

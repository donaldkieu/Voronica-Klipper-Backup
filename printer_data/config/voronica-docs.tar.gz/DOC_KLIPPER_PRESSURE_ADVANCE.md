# Klipper Pressure Advance Guide
*Source: klipper3d.org/Pressure_Advance.html — Full official documentation*

---

## What Pressure Advance Does

Pressure advance does two things:
1. Reduces ooze during non-extrude moves
2. Reduces blobbing during cornering

---

## Tuning Procedure

### Setup
Print the large hollow square tower: docs/prints/square_tower.stl

**Slicer settings for test:**
- High speed (e.g. 100mm/s)
- Zero infill
- Coarse layer height (~75% of nozzle diameter)
- Disable "dynamic acceleration control" and "scarf joint" seams

**Before printing, issue:**
```
SET_VELOCITY_LIMIT SQUARE_CORNER_VELOCITY=1 ACCEL=500
```
This slows corners to emphasize pressure advance effects.

**Then run tuning tower:**

For direct drive extruders (like Voronica's WWBMG):
```
TUNING_TOWER COMMAND=SET_PRESSURE_ADVANCE PARAMETER=ADVANCE START=0 FACTOR=.005
```

For long bowden extruders:
```
TUNING_TOWER COMMAND=SET_PRESSURE_ADVANCE PARAMETER=ADVANCE START=0 FACTOR=.020
```

### Reading the Print

- **Too low PA:** Blobbing at corners
- **Too high PA:** Rounded corners, poor extrusion leading into corners
- **Correct PA:** Clean sharp corners

Inspect print and use calipers to find height with best quality corners. When in doubt, prefer a lower height.

### Calculating PA Value
```
pressure_advance = START + measured_height * FACTOR
```
Example: 0 + 12.90 * .005 = 0.0645

### Applying the Result
Set in `[extruder]` config section:
```
pressure_advance: <calculated_value>
```
Then `RESTART` — clears test state and returns acceleration/cornering to normal values.

Or set at runtime without restart:
```
SET_PRESSURE_ADVANCE ADVANCE=<value>
```

---

## Important Notes

**PA is per-filament:** PA value depends on extruder, nozzle, AND filament. Filament from different manufacturers or with different pigments may require significantly different values. Calibrate with each spool.

**Temperature and flow rate matter:** Tune extruder rotation_distance and nozzle temperature BEFORE tuning PA.

**Typical PA values:**
- Direct drive: 0.020 to 0.100 typically
- Bowden: 0.050 to 1.000
- If no improvement with PA up to 1.000, PA is unlikely to help — disable it

**Corner variation:** One corner often looks different because slicer changes layers there. Ignore that corner, use other three for tuning.

**High PA + high accel:** If extruder skips, PA may be too high for the acceleration. Either reduce acceleration or lower PA.

**PA does NOT change:**
- Toolhead path or timing
- Total filament extruded
- Print time

PA only changes extruder movement RATE during acceleration/deceleration.

**After PA is tuned:**
- Consider small retract value in slicer (e.g. 0.75mm) to help with ooze
- "Wipe on retract" option in slicer can help
- Disable "z-lift on retract" in slicer when using PA

---

## Runtime Commands

```
SET_PRESSURE_ADVANCE ADVANCE=<value> [EXTRUDER=<name>] [SMOOTH_TIME=<seconds>]
```
Changes PA at runtime without restart. Not saved across restarts.

```
TUNING_TOWER COMMAND=SET_PRESSURE_ADVANCE PARAMETER=ADVANCE START=0 FACTOR=.005
```
Used for tuning — varies PA with layer height during print.

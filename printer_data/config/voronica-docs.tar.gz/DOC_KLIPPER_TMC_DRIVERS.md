# Klipper TMC Drivers Guide
*Source: klipper3d.org/TMC_Drivers.html — Full official documentation*
*Highly relevant to Voronica — TMC5160 (XY at 48V) and TMC2209 (Z + extruder)*

---

## Tuning Motor Current

A higher driver current increases positional accuracy and torque. However, a higher current also increases heat produced by the stepper motor and driver. If the stepper motor driver gets too hot it will disable itself and Klipper will report an error. If the stepper motor gets too hot, it loses torque and positional accuracy.

**General rule:** Prefer higher current values as long as:
- Stepper motor does not get too hot (warm is ok, painful to touch is not)
- Driver does not report warnings or errors

---

## Prefer to NOT Specify hold_current

If `hold_current` is configured, the TMC driver can reduce current when the stepper is not moving. However, changing motor current may itself introduce motor movement due to:
- "Detent forces" within the stepper motor (permanent magnet in rotor pulls towards iron teeth in stator)
- External forces on the axis carriage

Most stepper motors will not obtain a significant benefit to reducing current during normal prints, because few printing moves leave a stepper idle long enough to activate hold_current.

**Alternative:** Use `SET_TMC_CURRENT` commands in START_PRINT macro to adjust current before/after normal printing moves if needed.

---

## spreadCycle vs stealthChop Mode

**Default:** Klipper places TMC drivers in "spreadCycle" mode.
**Enable stealthChop:** Add `stealthchop_threshold: 999999` to TMC config section.

**spreadCycle:** Greater torque and greater positional accuracy. Recommended for performance.

**stealthChop:** Significantly lower audible noise, but:
- Increased "positional lag" of ~75% of a full-step during constant velocity moves
- For example, on a printer with 40mm rotation_distance and 200 steps_per_rotation, position deviation increases by ~0.150mm

**IMPORTANT:** Do NOT switch modes dynamically while motor is at non-zero velocity — produces poor and confusing results. Either always use spreadCycle (no stealthchop_threshold) or always use stealthChop (stealthchop_threshold: 999999).

**Voronica configuration:**
- X/Y TMC5160: stealthchop_threshold: 0 (always spreadCycle — correct for high performance)
- Z TMC2209: stealthchop_threshold: 999999 (always stealthChop — correct for quiet Z)
- Extruder TMC2209: stealthchop_threshold: 999999 (stealthChop is fine for extruder with pressure advance)

---

## TMC interpolate Setting

The `interpolate` setting may reduce audible noise at the cost of introducing a small systemic positional error. During constant velocity moves, error is approximately half a microstep distance minus 1/512 of a full step.

Example: 40mm rotation_distance, 200 steps_per_rotation, 16 microsteps → systemic error ~0.006mm

**For best positional accuracy:** Use spreadCycle + disable interpolation (`interpolate: False`) + increase microsteps to 64 or 128 for similar noise to interpolation without the positional error.

**If using stealthChop:** Positional inaccuracy from interpolation is small relative to stealthChop inaccuracy, so leave interpolation in default state (True).

---

## Sensorless Homing

**Note: Voronica does NOT use sensorless homing (uses physical endstops + Beacon). This section is for reference only.**

Sensorless homing allows homing without a physical limit switch. The carriage moves into the mechanical limit, the motor loses steps, the driver senses this via stallGuard and signals the MCU.

### Requirements
1. stallGuard capable TMC driver (tmc2130, tmc2209, tmc2660, or tmc5160)
2. SPI/UART interface wired to MCU (standalone mode doesn't work)
3. DIAG or SG_TST pin connected to MCU

### Configuration (tmc2209 example)
```
[tmc2209 stepper_x]
diag_pin: ^PA1      # MCU pin connected to TMC DIAG pin
driver_SGTHRS: 255  # 255 = most sensitive, 0 = least sensitive

[stepper_x]
endstop_pin: tmc2209_stepper_x:virtual_endstop
homing_retract_dist: 0  # MUST be 0 for sensorless
```

### Configuration (tmc5160/tmc2130 example)
```
[tmc5160 stepper_x]
diag1_pin: ^!PA1    # active low, so prefaced with ^!
driver_SGT: -64     # -64 = most sensitive, 63 = least sensitive

[stepper_x]
endstop_pin: tmc5160_stepper_x:virtual_endstop
homing_retract_dist: 0
```

### Key Rules for Sensorless Homing
- `homing_retract_dist` MUST be 0 — second homing move doesn't work with sensorless
- Do NOT set `hold_current` — causes movement after contact
- Pause at least 2 seconds before each homing attempt (clears driver stall flag)
- Move carriage away from endstop immediately after homing

### Sensitivity Values by Driver
- **tmc2209:** driver_SGTHRS — 255 = most sensitive, 0 = least sensitive
- **tmc2130/tmc5160:** driver_SGT — -64 = most sensitive, 63 = least sensitive
- **tmc2660:** driver_SGT — same as tmc2130/tmc5160

### Tuning Process (6 steps)
1. Set homing speed (good start: rotation_distance / 2 mm/s)
2. Configure config for sensorless
3. Find highest sensitivity (VALUE) that successfully homes (maximum_sensitivity)
4. Find lowest sensitivity that homes with single touch, no banging (minimum_sensitivity)
5. Set final value to: minimum_sensitivity + (maximum_sensitivity - minimum_sensitivity)/3, rounded to nearest integer
6. If range between max and min sensitivity is small (<5), increase homing speed

### CoreXY Tips for Sensorless Homing
- No `hold_current` on either stepper
- Keep both X and Y near center before each home attempt
- Home one axis, move away, pause 2 seconds, then home the other
- Do NOT home both simultaneously (stall detection can interfere)

---

## Querying and Diagnosing Drivers

`DUMP_TMC STEPPER=<name>` — Reports all fields configured by Klipper and all fields queryable from the driver. Interpret results against Trinamic datasheet for the specific driver.

---

## Configuring driver_XXX Settings

Low-level driver fields configured via `driver_XXX` settings in config or `SET_TMC_FIELD` command at runtime. Values correspond to actual register values in the Trinamic datasheet.

**Important note:** Trinamic datasheets sometimes confuse high-level settings (e.g. "hysteresis end") with low-level field values (e.g. HEND). In Klipper, `driver_XXX` and `SET_TMC_FIELD` always set the LOW-LEVEL field value. Example: if datasheet says write 3 to HEND to get "hysteresis end" of 0, set `driver_HEND=3`.

---

## TMC Error Diagnosis

### "Unable to read tmc uart 'stepper_x' register IFCNT"
- TMC2208/TMC2209 UART communication failure
- Check: motor power is enabled (driver needs motor power to communicate)
- If after first Klipper flash: remove ALL power for several seconds to reset driver state
- Otherwise: incorrect UART pin wiring or incorrect UART pin configuration in Klipper

### "Unable to write tmc spi 'stepper_x' register ..."
- TMC2130/TMC5160 SPI communication failure
- Check: motor power is enabled
- Check: SPI wiring and SPI pin configuration in Klipper
- Check: all devices on shared SPI bus are properly configured in Klipper
- Unused devices on shared SPI bus must be held high with `static_digital_output` to prevent bus corruption

### "TMC reports error: DRV_STATUS: ffffffff" or "READRSP@RDSEL2: 00000000"
- SPI communication error — likely SPI wiring problem or driver self-reset/failure

### "TMC reports error: ... ot=1(OvertempError!)"
- Driver overtemperature — disabled itself
- Solutions: decrease motor current, improve driver cooling, improve motor cooling

### "TMC reports error: ... ShortToGND" or "ShortToSupply"
- Very high current detected — loose or shorted motor wire
- Also possible with stealthChop if driver makes poor mechanical load prediction — try disabling stealthChop to test

### "TMC reports error: ... reset=1(Reset)" or "CS_ACTUAL=0(Reset?)"
- Driver reset itself mid-print
- Usually voltage or wiring issues

### "TMC reports error: ... uv_cp=1(Undervoltage!)"
- Driver detected low-voltage event
- Check wiring and power supply

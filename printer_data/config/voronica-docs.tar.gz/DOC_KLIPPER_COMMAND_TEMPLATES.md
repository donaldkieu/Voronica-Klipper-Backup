# Klipper Command Templates Reference
*Source: klipper3d.org/Command_Templates.html — Full official documentation*
*Essential for writing correct gcode_macro sections*

---

## Macro Naming Rules

- Case is not important — MY_MACRO and my_macro evaluate the same
- Numbers in macro name must be at the end (TEST_MACRO25 is valid, MACRO25_TEST3 is not)

---

## Formatting in Config File

Indentation is critical. The `gcode:` option starts at beginning of line; subsequent gcode lines must be indented:

```
[gcode_macro blink_led]
description: Blink my_led one time
gcode:
  SET_PIN PIN=my_led VALUE=1
  G4 P2000
  SET_PIN PIN=my_led VALUE=0
```

---

## Save/Restore State for Moves

Always use SAVE_GCODE_STATE / RESTORE_GCODE_STATE in macros that move the toolhead to avoid corrupting the caller's positioning mode:

```
[gcode_macro MOVE_UP]
gcode:
  SAVE_GCODE_STATE NAME=my_move_up_state
  G91
  G1 Z10 F300
  RESTORE_GCODE_STATE NAME=my_move_up_state
```

Always specify an explicit speed (F parameter) on the first G1 in any macro.

---

## Template Expansion (Jinja2)

Expressions are wrapped in `{ }`. Conditional statements use `{% %}`.

### Macro Parameters

Parameters passed to a macro are available via `params`. Parameter names are ALWAYS uppercase when evaluated. Parameters are ALWAYS strings — convert explicitly for math:

```
[gcode_macro SET_PERCENT]
gcode:
  M117 Now at { params.VALUE|float * 100 }%
```
Called as: `SET_PERCENT VALUE=.2` → outputs "Now at 20%"

Using default values with `set`:
```
[gcode_macro SET_BED_TEMPERATURE]
gcode:
  {% set bed_temp = params.TEMPERATURE|default(40)|float %}
  M140 S{bed_temp}
```

### Common Parameter Type Conversions
- `params.VALUE|int` — convert to integer
- `params.VALUE|float` — convert to float
- `params.VALUE|default(0)|int` — with default
- `params.VALUE|lower` — convert to lowercase string
- `params.VALUE|upper` — convert to uppercase string

### The "rawparams" Variable

Full unparsed parameters (including comments) for the running macro:
```
[gcode_macro M117]
rename_existing: M117_BASE
gcode:
  M117_BASE { rawparams }
```

### The "printer" Variable

Access current printer state via `printer` pseudo-variable:
```
[gcode_macro slow_fan]
gcode:
  M106 S{ printer.fan.speed * 0.9 * 255}
```

Key printer state objects relevant to Voronica:
```
printer.toolhead.position.x         # current X position
printer.toolhead.position.y         # current Y position
printer.toolhead.position.z         # current Z position
printer.toolhead.axis_maximum.x     # X axis max
printer.toolhead.axis_maximum.y     # Y axis max
printer.toolhead.axis_maximum.z     # Z axis max
printer.toolhead.axis_minimum.x     # X axis min
printer.toolhead.homed_axes         # string of homed axes e.g. "xyz"
printer.extruder.temperature        # current hotend temp
printer.extruder.target             # hotend target temp
printer.heater_bed.temperature      # current bed temp
printer.heater_bed.target           # bed target temp
printer.fan.speed                   # part cooling fan speed (0.0-1.0)
printer.print_stats.state           # "standby", "printing", "paused", "error", "complete"
printer.pause_resume.is_paused      # True/False
printer.quad_gantry_level.applied   # True if QGL has been applied this session
printer.configfile.settings.printer.max_velocity    # configured max velocity
printer.configfile.settings.printer.max_accel       # configured max accel
printer.configfile.settings.extruder.min_extrude_temp  # min temp to extrude
printer["gcode_macro MY_MACRO"].my_variable         # access macro variable
printer.save_variables.variables.my_var             # access saved variable
printer["heater_fan hotend_fan"].rpm                # fan tachometer RPM
printer["temperature_sensor chamber"].temperature   # chamber sensor temp
```

IMPORTANT: Macros are evaluated ENTIRELY first, then commands execute. State changes made by commands inside a macro are NOT visible to subsequent template expressions in the SAME macro evaluation. Separate macros called within see state at time they are invoked.

Access config sections with spaces using bracket notation:
```
printer["generic_heater my_chamber_heater"].temperature
```

---

## Action Commands

Available during macro evaluation (before gcode executes):

```
{ action_respond_info("message") }       # print "// message" to console
{ action_raise_error("error msg") }      # abort macro, print "!! error msg"
{ action_emergency_stop("reason") }      # put printer into shutdown state
{ action_call_remote_method("method", arg="value") }  # call remote client method
```

---

## Variables (Persistent Within Session)

Use `variable_<name>:` prefix in macro definition. Names must be lowercase. Changed at runtime with SET_GCODE_VARIABLE:

```
[gcode_macro start_probe]
variable_bed_temp: 0
gcode:
  SET_GCODE_VARIABLE MACRO=start_probe VARIABLE=bed_temp VALUE={printer.heater_bed.target}
  M140
  PROBE

[gcode_macro finish_probe]
gcode:
  M140 S{printer["gcode_macro start_probe"].bed_temp}
```

---

## Delayed Gcodes

```
[delayed_gcode clear_display]
gcode:
  M117

[gcode_macro load_filament]
gcode:
  G91
  G1 E50
  G90
  M400
  M117 Load Complete!
  UPDATE_DELAYED_GCODE ID=clear_display DURATION=10
```

Repeating delayed_gcode (self-updating):
```
[delayed_gcode report_temp]
initial_duration: 2.
gcode:
  {action_respond_info("Extruder Temp: %.1f" % (printer.extruder.temperature))}
  UPDATE_DELAYED_GCODE ID=report_temp DURATION=2
```

Cancel with: `UPDATE_DELAYED_GCODE ID=report_temp DURATION=0`

---

## Save Variables to Disk

```
SAVE_VARIABLE VARIABLE=<name> VALUE=<value>
```

Accessed in macros via:
```
{% set svv = printer.save_variables.variables %}
{svv.my_variable}
```

Note: As of Klipper 20250131, VARIABLE= parameter requires lowercase value only.

---

## Common Jinja2 Patterns in Klipper Macros

```
{% set speed = params.SPEED|default(100)|int %}        # int param with default
{% set temp = params.TEMP|default(200)|float %}        # float param with default
{% set name = params.NAME|default('default')|string %} # string param with default

{% if printer.toolhead.homed_axes == "xyz" %}          # check all homed
{% if 'x' in printer.toolhead.homed_axes %}            # check single axis homed
{% if printer.pause_resume.is_paused|int == 0 %}       # check not paused

{% set x_safe = [th.position.x + 20, th.axis_maximum.x]|min %}  # min of two values
{% set z_safe = [th.position.z + 2, th.axis_maximum.z]|min %}

{% for i in range(10) %}                               # loop
  G1 X{i * 10} F3000
{% endfor %}

{{ "%.3f" % some_float }}                              # format float to 3 decimal places
```

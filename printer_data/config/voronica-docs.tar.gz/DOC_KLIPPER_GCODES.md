# Klipper G-Code Command Reference
*Source: klipper3d.org/G-Codes.html — Full official documentation*
*Commands are case-insensitive. Parameters shown in uppercase.*

---

## Standard G-Code Commands

- Move: `G1 [X<pos>] [Y<pos>] [Z<pos>] [E<pos>] [F<speed>]` (F is mm/min, not mm/s — multiply mm/s by 60)
- Rapid move (alias for G1): `G0 [X<pos>] [Y<pos>] [Z<pos>] [F<speed>]`
- Dwell: `G4 P<milliseconds>`
- Move to origin / home: `G28 [X] [Y] [Z]`
- Turn off motors: `M18` or `M84`
- Wait for current moves to finish: `M400`
- Absolute extrusion: `M82`
- Relative extrusion: `M83`
- Absolute coordinates: `G90`
- Relative coordinates: `G91`
- Set position: `G92 [X<pos>] [Y<pos>] [Z<pos>] [E<pos>]`
- Set speed factor override %: `M220 S<percent>`
- Set extrude factor override %: `M221 S<percent>`
- Set acceleration: `M204 S<value>` OR `M204 P<value> T<value>`
- Get extruder temperature: `M105`
- Set extruder temperature (no wait): `M104 [T<index>] [S<temperature>]`
- Set extruder temperature and wait: `M109 [T<index>] S<temperature>` — Note: always waits for temp to settle
- Set bed temperature (no wait): `M140 [S<temperature>]`
- Set bed temperature and wait: `M190 S<temperature>` — Note: always waits for temp to settle
- Set fan speed: `M106 S<0-255>`
- Turn fan off: `M107`
- Emergency stop: `M112`
- Get current position: `M114`
- Get firmware version: `M115`
- Display message: `M117 <message>`
- Set build percentage: `M73 P<percent>`

---

## Extended G-Code Commands (Klipper-specific)

Extended commands start with a command name followed by parameters. Commands and parameters are NOT case-sensitive.

### [adxl345]
`ACCELEROMETER_MEASURE [CHIP=<config_name>] [NAME=<value>]`
Starts/stops accelerometer measurements. Results written to /tmp/adxl345-<chip>-<name>.csv

`ACCELEROMETER_QUERY [CHIP=<config_name>] [RATE=<value>]`
Queries accelerometer for current value. Useful to test connection.

### [bed_mesh]
`BED_MESH_CALIBRATE [PROFILE=<name>] [METHOD=manual] [HORIZONTAL_MOVE_Z=<value>] [<probe_parameter>=<value>] [<mesh_parameter>=<value>] [ADAPTIVE=1] [ADAPTIVE_MARGIN=<value>]`
Probes bed and generates mesh. If ADAPTIVE=1, limits mesh to print area defined by objects in gcode file.

`BED_MESH_OUTPUT [PGP=[0|1]]`
Outputs current probed z values and mesh values to terminal.

`BED_MESH_MAP`
Outputs mesh in JSON format (for plugins/visualizers).

`BED_MESH_CLEAR`
Clears the mesh and removes all z adjustment. Recommended in end-gcode.

`BED_MESH_PROFILE LOAD=<name>` OR `SAVE=<name>` OR `REMOVE=<name>`
Profile management. After SAVE or REMOVE, run SAVE_CONFIG to make permanent.

`BED_MESH_OFFSET [X=<value>] [Y=<value>] [ZFADE=<value>]`
Applies offsets to mesh lookup. Useful for printers with independent extruders.

### [configfile]
`SAVE_CONFIG`
Overwrites main printer config file and restarts host software. Used to save calibration results.

### [delayed_gcode]
`UPDATE_DELAYED_GCODE [ID=<name>] [DURATION=<seconds>]`
Updates delay duration for delayed_gcode and starts timer. Value 0 cancels pending execution.

### [display_status]
`SET_DISPLAY_TEXT [MSG=<message>]`
Sets current display message. If MSG omitted, clears display. Equivalent to M117.

### [extruder]
`ACTIVATE_EXTRUDER EXTRUDER=<config_name>`
In multi-extruder printers, changes the active hotend.

`SET_PRESSURE_ADVANCE [EXTRUDER=<config_name>] [ADVANCE=<pressure_advance>] [SMOOTH_TIME=<pressure_advance_smooth_time>]`
Sets pressure advance parameters. If EXTRUDER not specified, defaults to active hotend.

`SET_EXTRUDER_ROTATION_DISTANCE EXTRUDER=<config_name> [DISTANCE=<distance>]`
Sets new rotation_distance for extruder stepper. Changes not retained on Klipper reset.

`SYNC_EXTRUDER_MOTION EXTRUDER=<name> MOTION_QUEUE=<name>`
Synchronizes stepper to extruder movement. If MOTION_QUEUE is empty string, desynchronizes.

### [fan_generic]
`SET_FAN_SPEED FAN=<config_name> SPEED=<speed>`
Sets fan speed. Speed must be between 0.0 and 1.0.

### [filament_switch_sensor]
`QUERY_FILAMENT_SENSOR SENSOR=<sensor_name>`
Returns current status of filament sensor.

`SET_FILAMENT_SENSOR SENSOR=<sensor_name> ENABLE=[0|1]`
Enables or disables filament sensor.

### [firmware_retraction]
`SET_RETRACTION [RETRACT_LENGTH=<mm>] [RETRACT_SPEED=<mm/s>] [UNRETRACT_EXTRA_LENGTH=<mm>] [UNRETRACT_SPEED=<mm/s>]`
Sets firmware retraction parameters.

`GET_RETRACTION`
Queries and displays current firmware retraction parameters.

### [force_move]
(Requires [force_move] section with enable_force_move: True)

`STEPPER_BUZZ STEPPER=<config_name>`
Moves given stepper 1mm in positive direction then back, 10 times. Used to verify stepper wiring.

`FORCE_MOVE STEPPER=<config_name> DISTANCE=<value> VELOCITY=<value> [ACCEL=<value>]`
Manually moves stepper without kinematic limits. Use with caution.

`SET_KINEMATIC_POSITION [X=<value>] [Y=<value>] [Z=<value>]`
Forces Klipper to assume toolhead is at given position. Used for diagnostic moves.

### [gcode]
`RESTART`
Reloads Klipper config and restarts host software.

`FIRMWARE_RESTART`
Reloads config and restarts host software AND reinitialises MCU firmware.

`STATUS`
Reports current Klipper state to terminal.

`HELP`
Displays list of available extended G-Code commands.

### [gcode_macro]
`SET_GCODE_VARIABLE MACRO=<macro_name> VARIABLE=<name> VALUE=<value>`
Modifies the value of a gcode_macro variable at runtime.
Note: Variable names may not contain upper case characters.

### [gcode_move]
`GET_POSITION`
Provides information on current toolhead position (MCU stepper positions, gcode position, etc.)
Use to detect skipped steps — compare before/after high-speed moves.

`SET_GCODE_OFFSET [X=<pos>] [Y=<pos>] [Z=<pos>] [X_ADJUST=<adjust>] [Y_ADJUST=<adjust>] [Z_ADJUST=<adjust>] [MOVE=[0|1]] [MOVE_SPEED=<speed>]`
Sets a positional offset for gcode moves. Useful for adjusting Z offset at runtime.
Z= sets absolute offset. Z_ADJUST= adjusts by delta from current.

`SAVE_GCODE_STATE [NAME=<state_name>]`
Saves current G-Code coordinate parsing state including offsets, absolute/relative mode, fan, extruder.

`RESTORE_GCODE_STATE [NAME=<state_name>] [MOVE=[0|1]] [MOVE_SPEED=<speed>]`
Restores saved G-Code coordinate state. If MOVE=1, toolhead moves to saved position.

### [heaters]
`TURN_OFF_HEATERS`
Turns off all heaters.

`TEMPERATURE_WAIT SENSOR=<config_name> [MINIMUM=<value>] [MAXIMUM=<value>]`
Waits until temperature sensor reports within given range.

`SET_HEATER_TEMPERATURE HEATER=<heater_name> [TARGET=<target_temperature>]`
Sets target temperature for heater. Setting to 0 turns off heater.

### [idle_timeout]
`SET_IDLE_TIMEOUT [TIMEOUT=<timeout>]`
Sets printer idle timeout in seconds.

### [input_shaper]
`SET_INPUT_SHAPER [SHAPER_FREQ_X=<shaper_freq_x>] [SHAPER_FREQ_Y=<shaper_freq_y>] [DAMPING_RATIO_X=<damping_ratio_x>] [DAMPING_RATIO_Y=<damping_ratio_y>] [SHAPER_TYPE=<shaper>] [SHAPER_TYPE_X=<shaper_type_x>] [SHAPER_TYPE_Y=<shaper_type_y>]`
Sets input shaper parameters. Changes not retained on restart.

### [led]
`SET_LED LED=<config_name> RED=<value> GREEN=<value> BLUE=<value> [WHITE=<value>] [INDEX=<index>] [TRANSMIT=[0|1]] [SYNC=[0|1]]`
Sets LED color. Values between 0.0 and 1.0. INDEX specifies chip in chain (1-based).

### [output_pin]
`SET_PIN PIN=<config_name> VALUE=<value> [CYCLE_TIME=<cycle_time>]`
Sets value of output pin. For PWM pins, value is 0.0 to 1.0 (or 0 to scale value).

### [pause_resume]
`PAUSE`
Pauses current print.

`RESUME [VELOCITY=<value>]`
Resumes print from paused state.

`CLEAR_PAUSE`
Clears paused state without resuming.

`CANCEL_PRINT`
Cancels current print.

### [pid_calibrate]
`PID_CALIBRATE HEATER=<config_name> TARGET=<temperature> [WRITE_FILE=[0|1]]`
Performs PID calibration test. Results written to log and config via SAVE_CONFIG.

### [probe]
`PROBE [PROBE_SPEED=<mm/s>] [LIFT_SPEED=<mm/s>] [SAMPLES=<count>] [SAMPLE_RETRACT_DIST=<mm>] [SAMPLES_TOLERANCE=<mm>] [SAMPLES_TOLERANCE_RETRIES=<count>] [SAMPLES_RESULT=median|average]`
Performs single Z probe.

`QUERY_PROBE`
Reports current status of probe (triggered/open).

`PROBE_ACCURACY [PROBE_SPEED=<mm/s>] [SAMPLES=<count>] [SAMPLE_RETRACT_DIST=<mm>]`
Performs multiple Z probes and calculates statistics (max, min, mean, median, std deviation, range).

`PROBE_CALIBRATE [SPEED=<speed>] [<probe_parameter>=<value>]`
Starts interactive probe calibration (paper test).

`Z_OFFSET_APPLY_PROBE`
Takes current Z gcode offset (from babystep) and applies it to probe z_offset.
Requires SAVE_CONFIG to persist.

### [quad_gantry_level]
`QUAD_GANTRY_LEVEL [RETRY_TOLERANCE=<value>] [RETRIES=<value>] [HORIZONTAL_MOVE_Z=<value>] [<probe_parameter>=<value>]`
Levels moving gantry using 4 Z motors. Requires [quad_gantry_level] config section.

### [query_endstops]
`QUERY_ENDSTOPS`
Probes all configured endstops and reports their status (open/triggered).

### [resonance_tester]
`MEASURE_AXES_NOISE [CHIP=<config_name>]`
Measures and reports noise levels for all axes of accelerometer.

`TEST_RESONANCES AXIS=<axis> [CHIP=<config_name>] [OUTPUT=resonances] [NAME=<name>] [FREQ_START=<min_freq>] [FREQ_END=<max_freq>] [HZ_PER_SEC=<hz_per_sec>] [ACCEL_PER_HZ=<accel_per_hz>]`
Runs resonance test for given axis. AXIS can be X, Y, Z, or a direction vector.
Writes results to /tmp/resonances_<axis>_<name>.csv for shaper analysis.

`SHAPER_CALIBRATE [AXIS=<axis>] [NAME=<name>] [FREQ_START=<min_freq>] [FREQ_END=<max_freq>] [HZ_PER_SEC=<hz_per_sec>] [MAX_SMOOTHING=<max_smoothing>]`
Runs resonance test and automatically selects best input shaper. Results saved via SAVE_CONFIG.
Note: ShakeTune replaces this with more advanced analysis on Voronica.

### [respond]
`RESPOND [TYPE=<type>] [PREFIX=<prefix>] MSG=<message>`
Outputs message to console. TYPE can be echo, command, or error.

### [save_variables]
`SAVE_VARIABLE VARIABLE=<name> VALUE=<value>`
Saves variable to disk (variables.cfg). Loaded into printer.save_variables.variables on restart.
Note: Variable names must be lowercase as of Klipper 20250131.

### [stepper_enable]
`SET_STEPPER_ENABLE STEPPER=<config_name> ENABLE=[0|1]`
Enables or disables individual stepper. Use with extreme care — can cause machine movement.

### [tmcXXXX]
`DUMP_TMC STEPPER=<name>`
Dumps all TMC driver registers to console. Useful for diagnostics.

`INIT_TMC STEPPER=<name>`
Reinitializes TMC driver settings from config. Use after SET_TMC_CURRENT to re-apply config values.

`SET_TMC_CURRENT STEPPER=<name> CURRENT=<amps> [HOLDCURRENT=<amps>]`
Adjusts run and hold currents of TMC driver at runtime.
IMPORTANT for TMC5160: If StealthChop2 is used, stepper must be held still for >130ms after SET_TMC_CURRENT for AT#1 calibration. Not applicable to Voronica (stealthchop OFF on XY TMC5160).
HOLDCURRENT not applicable to tmc2660.

`SET_TMC_FIELD STEPPER=<name> FIELD=<field> VALUE=<value>`
Alters specific TMC register field. For low-level diagnostics only — can cause dangerous behavior.
Permanent changes should be made via config file.

### [toolhead]
`SET_VELOCITY_LIMIT [VELOCITY=<value>] [ACCEL=<value>] [MINIMUM_CRUISE_RATIO=<value>] [SQUARE_CORNER_VELOCITY=<value>]`
Sets printer velocity limits at runtime.
NOTE: Use MINIMUM_CRUISE_RATIO not ACCEL_TO_DECEL (deprecated).

### [tuning_tower]
`TUNING_TOWER COMMAND=<command> PARAMETER=<name> START=<value> [SKIP=<value>] [FACTOR=<value> [BAND=<value>]] | [STEP_DELTA=<value> STEP_HEIGHT=<value>]`
Tool for tuning a parameter by varying it at each layer height.

### [virtual_sdcard]
`SDCARD_PRINT_FILE FILENAME=<filename>`
Opens and prints given file from virtual sdcard.

`SDCARD_RESET_FILE`
Unloads file and clears virtual sdcard state.

### [z_tilt]
`Z_TILT_ADJUST [HORIZONTAL_MOVE_Z=<value>] [RETRIES=<value>] [RETRY_TOLERANCE=<value>] [<probe_parameter>=<value>]`
Adjusts Z steppers to compensate for bed tilt (for printers with multiple Z steppers but not QGL).

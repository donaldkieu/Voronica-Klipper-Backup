# Klippain ShakeTune — Documentation Reference
*Extracted from github.com/Frix-x/klippain-shaketune*
*Applicable to: ShakeTune v6.0.0-0-g354ee4be (standalone install)*

---

## [shaketune] Config Section

```
[shaketune]
result_folder: ~/printer_data/config/ShakeTune_results
    # Path where processed results (graphs) are stored
    # Folder created automatically if it doesn't exist

number_of_results_to_keep: 1000
    # How many result sets to retain before auto-deleting oldest
    # Voronica: set to 1000

keep_raw_data: False
    # If True, stores both graphs AND raw .stdata accelerometer files
    # Useful for debugging or re-processing with newer ShakeTune version
    # Set True when reporting issues to developer

show_macros_in_webui: True
    # Injects ShakeTune macros as buttons in Mainsail/Fluidd at runtime
    # If False, macros still work from console but no UI buttons

timeout: 600
    # Max processing time in seconds for generating graphs
    # 10 minutes is sufficient for most hardware
    # Increase if getting timeout errors on slow SD cards

measurements_chunk_size: 2
    # Measurements written to disk per chunk
    # 2 = conservative, avoids "Timer Too Close" on low-RAM devices
    # Increase to 15–20 on powerful computers to reduce filesystem stress

max_freq: 200
    # Maximum frequency (Hz) for PSD calculation cutoff
    # Default is fine — do not change unless you know why

dpi: 300
    # Graph resolution — optimized default, no need to change
```

---

## ShakeTune Commands

### AXES_MAP_CALIBRATION
```
AXES_MAP_CALIBRATION [Z_HEIGHT=<mm>] [SPEED=<mm/s>] [ACCEL=<mm/s²>]
    [DETECT_SPIRALING=<0|1>]
```
- Automatically detects and sets the `axes_map` parameter for the accelerometer
- Machine moves slightly in +X, +Y, +Z to detect orientation
- Output in console: `Detected axes_map: x,z,-y`
- Experimental — useful when unsure of axes_map after mounting change
- **Note:** Klipper does not support tilted accelerometers — mount must be aligned with machine axes for accurate results

---

### BELTS_SHAPER_CALIBRATION (formerly COMPARE_BELTS_RESPONSES)
```
BELTS_SHAPER_CALIBRATION [FREQ_START=<hz>] [FREQ_END=<hz>] [HZ_PER_SEC=<hz/s>]
    [ACCEL_CHIP=<chip>] [MAX_SMOOTHING=<value>]
```
- Measures and compares resonance responses of CoreXY belt paths (A vs B belts)
- Generates graph showing if belts are balanced — peaks should overlap
- **Use for:** belt tension verification, differential belt path diagnosis
- AWD machines (like Voronica): run after SYNC_MOTORS to compare all belt pairs
- Results stored in `result_folder` as graphs

---

### AXES_SHAPER_CALIBRATION
```
AXES_SHAPER_CALIBRATION [AXIS=<X|Y|all>] [FREQ_START=<hz>] [FREQ_END=<hz>]
    [HZ_PER_SEC=<hz/s>] [ACCEL_CHIP=<chip>] [MAX_SMOOTHING=<value>]
    [SCALER=<value>]
```
- Full input shaper calibration for X and/or Y axes
- Generates resonance graphs with recommended shaper type and frequency
- Includes damping ratio measurement (Kalico-specific feature)
- **Output:** recommended `shaper_type`, `shaper_freq`, `damping_ratio` values for `[input_shaper]`
- **After running:** update `[input_shaper]` in printer.cfg with recommended values, then `SAVE_CONFIG`

---

### CREATE_VIBRATIONS_PROFILE
```
CREATE_VIBRATIONS_PROFILE [ACCEL=<mm/s²>] [ACCEL_CHIP=<chip>]
    [MIN_SPEED=<mm/s>] [MAX_SPEED=<mm/s>] [SPEED_INCREMENT=<mm/s>]
```
- Measures global machine vibrations as a function of toolhead direction and speed
- Identifies speed ranges with high VFA (visible fine artifact) risk
- **Use for:** optimising slicer speed profiles, finding problematic TMC driver ranges
- Most useful after mechanical changes or when print quality varies with speed

---

### EXCITATE_AXIS_AT_FREQ
```
EXCITATE_AXIS_AT_FREQ AXIS=<X|Y|Z|a|b> FREQ=<hz> [DURATION=<sec>] [ACCEL=<mm/s²>]
    [ACCEL_CHIP=<chip>]
```
- Maintains a specific excitation frequency for a set duration
- **Use for:** diagnosing parasite resonance peaks — touch components while running to identify vibration source (contact usually stops it)
- `AXIS=a` or `AXIS=b` tests CoreXY belt directions independently
- Also useful for finding what is resonating at a specific frequency

---

### AXES_MAP_CALIBRATION
```
AXES_MAP_CALIBRATION [Z_HEIGHT=<>] [SPEED=<>] [ACCEL=<>]
```
- Auto-detects correct `axes_map` for accelerometer — experimental tool

---

## Interpreting Results

### Input Shaper Graphs (AXES_SHAPER_CALIBRATION)
- **Sharp single peak:** good — clean resonance, easy to compensate
- **Multiple peaks or broad peak:** mechanical issue — check belt tension, loose screws, frame rigidity
- **High frequency (>100Hz):** good for high-speed printing with AWD/Monolith setup
- **Low Y frequency (<48Hz):** prioritise mechanical stiffening before increasing acceleration
- **Damping ratio:** higher = more damping = more forgiving of speed changes. Kalico uses this to improve IS accuracy

### Belt Comparison Graphs (BELTS_SHAPER_CALIBRATION)
- **Peaks aligned:** belts well balanced — good
- **Peaks misaligned:** tension imbalance between A/B belts — adjust
- **For AWD:** run after SYNC_MOTORS — phase offsets affect belt balance readings

---

## Workflow for Voronica (AWD)

Recommended order for a full tune session:
1. `SYNC_MOTORS` — synchronise AWD belt phase
2. `BELTS_SHAPER_CALIBRATION` — verify belt balance after sync
3. `AXES_SHAPER_CALIBRATION` — measure resonances and get IS recommendations
4. Update `[input_shaper]` with results from graphs
5. `CREATE_VIBRATIONS_PROFILE` — optional, find optimal speed ranges

---

# motors-sync — Documentation Reference
*Extracted from github.com/MRX8024/motors-sync*
*Applicable to: motors-sync V2.0.0-35-g0e59ed78*

---

## [motors_sync] Config Section

```
[motors_sync]
axes: x,y
    # Axes on which AWD synchronisation will be performed

accel_chip: adxl345
    # Accelerometer for vibrations collection: adxl345 | mpu9250 | beacon | etc
    # Voronica uses adxl345 on EBBCan

# Optional parameters (commented out = default):
#encoder_chip_<axis>:
    # Axis-assigned encoder name for measuring deviations

#chip_filter: median
    # Filter for accelerometer data: median | kalman
    # median works for most; kalman for noisy printers (fans etc)

#median_size: 3
    # Median filter window size

#microsteps: 16
    # Max microstepping displacement of rotor

#steps_model: linear, 20000, 0
    # Mathematical model for microstep displacement vs measured magnitude

#max_step_size: 3
    # Max microsteps motor can move at one time

#retry_tolerance: 0
    # Threshold to force further sync iterations
    # Set after finding edge from several runs

#retries: 0
    # Max repetitions to reach forced threshold
```

---

## SYNC_MOTORS Command

```
SYNC_MOTORS [AXES=<x,y>]
```
- Runs AWD belt synchronisation using accelerometer measurements
- Adjusts motor phase offsets between paired motors (stepper_x vs stepper_x1, stepper_y vs stepper_y1) to minimise belt resonance mismatch
- Results saved automatically to `variables.cfg` as `motors_sync_phase_offset`
- **When to run:**
  - After any belt tension change
  - After motor swap or driver change
  - After any mechanical work on gantry
  - As part of PRINT_START (already in Voronica's PRINT_START macro)
  - After autotune changes

---

## Phase Offsets

Saved automatically to `~/variables.cfg`:
```
motors_sync_phase_offset = {'y': -240, 'x': 384}
```
- These values represent the microstepping phase offset between paired AWD motors
- **Do not manually edit** — always re-run SYNC_MOTORS to update
- Values change with belt tension, temperature, and mechanical state
- After sync, run `BELTS_SHAPER_CALIBRATION` to verify improvement

---

## Notes for AWD / Monolith Setup

- Run `SYNC_MOTORS` before `BELTS_SHAPER_CALIBRATION` — sync directly affects belt comparison readings
- If belt comparison shows persistent misalignment after sync, check:
  - Belt tension on all 4 belts (should be equal)
  - Belt path differences between A1/A2 and B1/B2 sides
  - Motor coupling tightness
- `head_fan` parameter (commented out in Voronica config): can turn off hotend fan during sync to reduce accelerometer noise — useful if readings are inconsistent

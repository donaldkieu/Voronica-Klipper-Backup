# Klipper Measuring Resonances Guide
*Source: klipper3d.org/Measuring_Resonances.html — Full official documentation*
*Voronica uses ADXL345 on EBBCan (axes_map: x,z,-y)*

---

## Supported Accelerometers
- ADXL345 (SPI) — used on Voronica via EBBCan
- MPU-9250/9255/6515/6050/6500/ICM20948 (I2C)
- LIS2DW, LIS3DH (SPI or I2C)

For ADXL345: must use SPI mode. Boards that pull SDO to GND are hard-coded for I2C and will NOT work.

---

## Software Installation (required before first use)

On Raspberry Pi:
```bash
sudo apt update
sudo apt install python3-numpy python3-matplotlib libatlas-base-dev libopenblas-dev
~/klippy-env/bin/pip install -v "numpy<1.26"
```

Verify: `~/klippy-env/bin/python -c 'import numpy;'` — should output a blank line with no error.

---

## Voronica Config (ADXL345 on EBBCan)

```ini
[adxl345]
cs_pin: EBBCan:gpio1
spi_software_sclk_pin: EBBCan:gpio2
spi_software_mosi_pin: EBBCan:gpio0
spi_software_miso_pin: EBBCan:gpio3
axes_map: x,z,-y

[resonance_tester]
accel_chip: adxl345
probe_points:
    150, 150, 20
```

Note: `axes_map: x,z,-y` is Voronica's confirmed orientation for EBBCan-mounted ADXL345.

---

## Checking the Setup

```
ACCELEROMETER_QUERY
```
Should return current readings including free-fall acceleration (~9.8 m/s² on one axis), e.g.:
```
adxl345 values (x, y, z): 470.719200, 941.438400, 9728.196800
```

If you get `Invalid adxl345 id (got xx vs e5)` — retry once. If it persists, check SPI wiring.

```
MEASURE_AXES_NOISE
```
Baseline noise check. Expect ~1–100. Values >1000 indicate sensor issues, power problems, or noisy fans.

---

## Running Resonance Tests

**IMPORTANT:** Disable input shaper before testing:
```
SET_INPUT_SHAPER SHAPER_FREQ_X=0 SHAPER_FREQ_Y=0
```

Run tests:
```
TEST_RESONANCES AXIS=X
TEST_RESONANCES AXIS=Y
```

This creates CSV files: `/tmp/resonances_x_*.csv` and `/tmp/resonances_y_*.csv`

Watch the printer during the first run — if vibrations are too violent, `M112` to abort. If needed, reduce:
```ini
[resonance_tester]
accel_per_hz: 50   # default is 60, lower = less aggressive
```

---

## Processing Results

On the Raspberry Pi:
```bash
~/klipper/scripts/calibrate_shaper.py /tmp/resonances_x_*.csv -o /tmp/shaper_calibrate_x.png
~/klipper/scripts/calibrate_shaper.py /tmp/resonances_y_*.csv -o /tmp/shaper_calibrate_y.png
```

Example output:
```
Fitted shaper 'zv' frequency = 34.4 Hz (vibrations = 4.0%, smoothing ~= 0.132)
To avoid too much smoothing with 'zv', suggested max_accel <= 4500 mm/sec^2
Fitted shaper 'mzv' frequency = 34.6 Hz (vibrations = 0.0%, smoothing ~= 0.170)
To avoid too much smoothing with 'mzv', suggested max_accel <= 3500 mm/sec^2
Fitted shaper 'ei' frequency = 41.4 Hz (vibrations = 0.0%, smoothing ~= 0.188)
To avoid too much smoothing with 'ei', suggested max_accel <= 3200 mm/sec^2
Recommended shaper is mzv @ 34.6 Hz
```

Choose the shaper with 0% or lowest vibrations and the highest acceptable max_accel. Apply to config:
```ini
[input_shaper]
shaper_freq_x: ...
shaper_type_x: mzv
shaper_freq_y: 34.6
shaper_type_y: mzv
```

---

## Auto-Calibration (SHAPER_CALIBRATE)

Runs test and applies best shaper automatically:
```
SHAPER_CALIBRATE          # calibrate both axes
SHAPER_CALIBRATE AXIS=X   # calibrate X only
SHAPER_CALIBRATE AXIS=Y   # calibrate Y only
```

After completion, run `SAVE_CONFIG` to persist results.

**Note:** ShakeTune (installed on Voronica) provides more advanced analysis than the built-in calibrate_shaper.py. Use ShakeTune commands instead — see DOC_SHAKETUNE_MOTORSSYNC.md.

---

## Max Smoothing Parameter

Optional — limits how much smoothing SHAPER_CALIBRATE will accept:
```ini
[resonance_tester]
max_smoothing: 0.1   # lower = less smoothing allowed = potentially lower accel
```

If not set, no smoothing limit is enforced. Useful if you want to prioritize speed limits over smoothing.

---

## Selecting max_accel from Results

From the calibrate_shaper.py output, each shaper suggests a max_accel. Use the value from your chosen shaper as the upper bound for max_accel. Also check the smoothing test (0.15mm gap in ringing tower) to find the practical limit.

Final max_accel = minimum of:
1. Suggested max_accel from shaper script
2. Acceleration where smoothing gap appears in test print

---

## Testing Custom Axes (AWD / belt resonance)

For AWD printers like Voronica, you can test individual belt axes:
```
TEST_RESONANCES AXIS=1,1    # A belt (X+Y)
TEST_RESONANCES AXIS=1,-1   # B belt (X-Y)
```
Or use ShakeTune's BELTS_SHAPER_CALIBRATION for proper belt resonance analysis.

---

## Z Axis Resonance

```
TEST_RESONANCES AXIS=Z
```
Useful for diagnosing Z ringing. Z IS calibration is generally not recommended unless Z ringing is a visible problem.

---

## Offline Processing

If you collected multiple CSV files and want to average them:
```bash
~/klipper/scripts/calibrate_shaper.py /tmp/resonances_x_*.csv -o /tmp/shaper_calibrate_x.png
```
Delete extra CSV files you don't want to average before running the script.

# Klipper Bed Leveling + Probe Calibration Guide
*Source: klipper3d.org/Bed_Level.html and klipper3d.org/Probe_Calibrate.html — Full official documentation*
*Note: Voronica uses Beacon3D contact scanner + QGL, not traditional probe — see DOC_BEACON3D.md for Beacon-specific workflow. This file covers the underlying Klipper concepts.*

---

# BED LEVELING

## The Goal
If the printer is commanded to X0 Y0 Z10, the nozzle should be exactly 10mm from the bed. On a move to X50 Z10, the nozzle should maintain exactly 10mm across the entire horizontal move. Target accuracy: within ~25 microns (0.025mm) — smaller than a human hair. This cannot be measured by eye; the secret is a repeatable process that leverages the printer's own motion-system accuracy.

## Prerequisites
- Run the checks in the Config Checks document FIRST — verify basic printer motion before bed leveling.
- For automatic Z probe: calibrate the probe per Probe Calibrate (below).
- During calibration it may be necessary to set Z `position_min` to a negative number (e.g. `position_min: -2`) so the printer can move below nominal bed position. Klipper enforces boundary checks even during calibration.

## The "Paper Test"
The primary calibration mechanism, underlying all the others. Even with an automatic Z probe, understand this because the probe itself is calibrated using the paper test.

**Procedure:**
1. Cut a small rectangle of copy paper (~5×3 cm). Paper thickness ~100 microns (0.100mm) — exact thickness isn't crucial.
2. **Inspect nozzle and bed — ensure NO plastic/debris.** If plastic is present, heat extruder, remove with metal tweezers, then let cool fully.
3. **ALWAYS perform the paper test with nozzle AND bed at ROOM TEMPERATURE.**
   - Thermal expansion when heated is ~100 microns, about the same as paper thickness — start by assuming the two are equal.
   - Calibrating hot imparts molten plastic on the paper (changes friction) and risks burns. Thermal expansion is stable, so it's accounted for later.

**Use an automated tool to find precise Z heights:** MANUAL_PROBE, Z_ENDSTOP_CALIBRATE, PROBE_CALIBRATE, or DELTA_CALIBRATE.

The tool prompts in the terminal:
```
// Z position: ?????? --> 5.000 <-- ??????
```
The current nozzle height is between the `--> <--`. The number on the right is the last probe attempt just greater than current; left is last attempt less than current (or ?????? if none).

**Adjusting with TESTZ:**
```
TESTZ Z=-.1     # move nozzle 0.1mm CLOSER to bed (relative move)
TESTZ Z=+.1     # move nozzle 0.1mm UP
TESTZ Z=-       # bisect — move halfway between the two bracketing positions
TESTZ Z=+       # bisect upward
TESTZ Z=--      # return directly to the lower past measurement
TESTZ Z=++      # return directly to the higher past measurement
```
Example: prompt `Z position: 0.130 --> 0.230 <-- 0.280`. A `TESTZ Z=-` moves to 0.180 (halfway between 0.130 and 0.230). A `TESTZ Z=--` returns to 0.130.

Push paper back and forth after each move; continue until you feel a small amount of friction. Then:
```
ACCEPT      # accept Z height, proceed with calibration tool
ABORT       # exit if something goes wrong
```
The exact friction isn't crucial — just aim for the SAME friction each time.

## Determining Thermal Expansion (optional refinement)
Most users find the plain paper test sufficient. For a more precise combined value of thermal expansion + paper thickness + friction:
1. Print a hollow square with straight walls (docs/prints/square.stl), coarse layer height (~75% nozzle diameter), no brim/raft, same first-layer width as subsequent layers.
2. Inspect/feel the bottom layer:
   - **Bulges out on all sides** → nozzle was too close → `SET_GCODE_OFFSET Z=+.010` to raise.
   - **Bottom layer narrower than subsequent layers** → use negative Z adjustment.
3. Apply via a SET_GCODE_OFFSET in your START_PRINT macro. Adjustments are typically tens of microns (.010mm).

---

# PROBE CALIBRATION

For configs with a `[probe]` or `[bltouch]` section.

## Calibrating Probe X and Y Offsets
1. Home printer, move head near center of bed.
2. Place blue painters tape on bed under the probe.
3. Issue `PROBE`. Mark the tape directly under where the probe triggered.
4. Issue `GET_POSITION`, record toolhead XY (e.g. X:46.5 Y:27.0 → probe position 46.5, 27).
5. Use G1 moves until the NOZZLE is directly above the mark:
   ```
   G1 F300 X57 Y30 Z15
   ```
6. `GET_POSITION` again → this is the nozzle position.
7. Calculate:
   ```
   x_offset = nozzle_x_position - probe_x_position
   y_offset = nozzle_y_position - probe_y_position
   ```
8. Update printer.cfg, remove tape, `RESTART`.

## Calibrating Probe Z Offset
z_offset = distance between nozzle and bed when the probe triggers. Critical for print quality.

1. Home, move head near center of bed.
2. Run `PROBE_CALIBRATE` — performs automatic probe, lifts head, moves nozzle over the probe point, starts manual probe tool.
   - If the nozzle does NOT move above the probe point, `ABORT` and do the XY offset calibration first.
3. Follow the paper test with TESTZ commands.
4. `ACCEPT`, then `SAVE_CONFIG`.

**What invalidates PROBE_CALIBRATE results:**
- Changes to motion system, hotend position, or probe location.
- Bed tilt changes: adjusting bed screws, DELTA_CALIBRATE, Z_TILT_ADJUST, QUAD_GANTRY_LEVEL (if probe has X/Y offset).
- **If invalidated, previous bed mesh results are ALSO invalidated** — rerun BED_MESH_CALIBRATE after recalibrating the probe.

## Repeatability Check (PROBE_ACCURACY)
1. Home, move head near center of bed.
2. Run `PROBE_ACCURACY` — probes 10 times, reports max/min/range/average/median/std deviation.

**Interpreting results:**
- Ideally max == min.
- Normal for min/max to differ by one Z step distance or up to 5 microns (.005mm).
- Step distance = `rotation_distance / (full_steps_per_rotation * microsteps)`.
- **Range > 25 microns (.025mm) → probe lacks sufficient accuracy** for typical bed leveling.
- Tuning options: adjust probe speed, probe start height, or use multiple `samples` per probe to average out occasional outliers.
- After changing settings, `RESTART` and recalibrate z_offset.
- If repeatable results can't be obtained, don't use the probe for leveling — use manual probing tools instead.

## Location Bias Check
Some probes have a systemic bias at certain toolhead locations (e.g. probe mount tilts along Y). Common on deltas but occurs on all printers.
1. Calibrate X, Y, Z offsets first.
2. Run `PROBE_CALIBRATE` at multiple XY locations (four bed corners for cartesian/corexy; near each tower for delta), noting reported z_offset each time — but do NOT `SAVE_CONFIG`.
3. **If max z_offset − min z_offset > 25 microns (.025mm) → probe not suitable** for typical bed leveling.

## Temperature Bias
Many probes trigger at different heights at different temperatures (e.g. lower height when hotter).
- Run bed leveling tools at a CONSISTENT temperature (always room temp, or always at print temp).
- Wait several minutes after reaching target temp so the apparatus is uniformly heated.
- **To check:** run `PROBE_ACCURACY` at room temp, then (without homing or disabling steppers) heat nozzle+bed to print temp and run `PROBE_ACCURACY` again. Ideally identical. If biased, always use the probe at a consistent temperature.

---

## Voronica-Specific Notes
- Voronica uses a **Beacon3D contact scanner** (eddy-current + contact) and **quad_gantry_level**, not a traditional Z probe or bed screws.
- Beacon handles Z offset and homing differently — see DOC_BEACON3D.md for BEACON_CALIBRATE, BEACON_AUTO_CALIBRATE, contact vs proximity modes.
- QGL replaces the manual bed-tramming step (gantry leveled to bed via 4 independent Z motors). See DOC_KLIPPER_CONFIG_REFERENCE.md [quad_gantry_level].
- The paper-test concepts above still apply to understanding Beacon's contact-based nozzle-offset calibration.

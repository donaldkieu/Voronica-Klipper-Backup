# Klipper Slicers Guide + Config Changes Reference
*Source: klipper3d.org/Slicers.html and klipper3d.org/Config_Changes.html*

---

# Slicers Guide

## G-Code Flavor Setting
Set slicer G-Code flavor to **Marlin** (works well with Klipper). "Smoothieware" also works.

---

## Using START_PRINT / END_PRINT Macros

Define macros in Klipper config rather than in slicer start/end gcode. Call them from slicer:

**OrcaSlicer / Bambu Studio start gcode:**
```
START_PRINT BED=[bed_temperature_initial_layer_single] EXTRUDER=[nozzle_temperature_initial_layer]
```

**Cura start gcode:**
```
START_PRINT BED_TEMP={material_bed_temperature_layer_0} EXTRUDER_TEMP={material_print_temperature_layer_0}
```

**PrusaSlicer / SuperSlicer start gcode:**
```
M140 S0
M104 S0
START_PRINT EXTRUDER_TEMP=[first_layer_temperature] BED_TEMP=[first_layer_bed_temperature]
```
(The M140/M104 S0 lines prevent the slicer from inserting its own heating gcode)

---

## Slicer Settings to Avoid with Klipper

| Setting | Action | Reason |
|---|---|---|
| "Coasting" | DISABLE | Results in poor quality — use Pressure Advance instead |
| "Advanced extruder pressure" | DISABLE | Conflicts with Klipper's PA; can trigger max extrusion cross-section errors |
| "PreloadVE" (KISSlicer) | SET TO 0 | Same reason — use PA instead |
| "Extra restart distance" (Simplify3D) | AVOID | Can trigger max extrusion cross-section check |

## Settings That Work Fine with Klipper
- Retract setting
- Wipe setting
- Wipe on retract
- Dynamic acceleration control: DISABLE (interferes with IS tuning)

---

## Large Retraction with Klipper

Large retraction (≥5mm) may be limited by:
```
max_extrude_only_velocity:   # default auto-calculated
max_extrude_only_accel:      # default auto-calculated
```

If toolhead "pauses" during retraction, explicitly set these in [extruder] config or use Pressure Advance instead.

---

## OrcaSlicer Specific (Voronica)

OrcaSlicer is Bambu-derived with full Klipper support. Key points:
- Uses `[bed_temperature_initial_layer_single]` and `[nozzle_temperature_initial_layer]` placeholders
- Supports FILAMENT_PROFILE and BED_TYPE variables
- Pressure Advance: set per-filament profile in OrcaSlicer, or use Klipper's native PA
- Machine limits: set to match printer.cfg values (max_velocity, max_accel, etc.)
- Disable "dynamic acceleration control" when tuning input shaper
- "Scarf joint" seams: disable when running PA or IS tuning tests

---

# Config Changes Reference (Deprecated/Changed Settings)

*Key changes to be aware of — do not suggest deprecated settings*

## Deprecated and Removed Parameters

| Deprecated | Replacement | Date |
|---|---|---|
| `max_accel_to_decel` | `minimum_cruise_ratio` | ~2023 |
| `ACCEL_TO_DECEL=` in SET_VELOCITY_LIMIT | `MINIMUM_CRUISE_RATIO=` | ~2023 |
| `relative_reference_index` in bed_mesh | `zero_reference_position` | 20230619 |
| `bed_mesh` auto-loads default on startup | Must explicitly call `BED_MESH_PROFILE LOAD=default` | 20230201 |
| `SET_EXTRUDER_STEP_DISTANCE` | `SET_EXTRUDER_ROTATION_DISTANCE` | 20220210 |
| `SYNC_STEPPER_TO_EXTRUDER` | `SYNC_EXTRUDER_MOTION` | 20220210 |
| `extruder shared_heater` option | `extruder_stepper` config section | 20220210 |
| `NTC 100K beta 3950` thermistor name | `Generic 3950` | 20211110 |
| `output_pin maximum_mcu_duration` | `pwm_tool` config section | 20240123 |
| `output_pin static_value` | `value` and `shutdown_value` parameters | 20240123 |
| `SAVE_VARIABLE VARIABLE=` uppercase names | must be lowercase | 20250131 |

## Important Behavior Changes

**SET_TMC_CURRENT on TMC5160 (20230304):**
Now properly adjusts globalscaler register. After SET_TMC_CURRENT on TMC5160 with stealthchop: stepper must be held still for >130ms for AT#1 calibration. (Not applicable to Voronica — stealthchop OFF on XY TMC5160.)

**Resonance test sweep (20241203):**
Resonance test now includes slow sweeping moves by default. `sweeping_accel` and `sweeping_period` config options added to `[resonance_tester]`.

**manual_stepper STOP_ON_ENDSTOP (20250418):**
Now completes faster after endstop triggers (no longer waits full possible duration).

**SPI software rate limiting (20250417):**
`spi_speed` in config is now actually enforced for software SPI. Previously ignored.

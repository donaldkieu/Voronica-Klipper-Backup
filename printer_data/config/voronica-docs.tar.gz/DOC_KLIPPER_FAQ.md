# Klipper FAQ
*Source: klipper3d.org/FAQ.html — Full official documentation*

---

## Finding Your Serial Port
```
ls /dev/serial/by-id/*
```
Example output: `/dev/serial/by-id/usb-1a86_USB2.0-Serial-if00-port0`
This name is STABLE — use it in config and flashing. Flash example:
```
sudo service klipper stop
make flash FLASH_DEVICE=/dev/serial/by-id/usb-1a86_USB2.0-Serial-if00-port0
sudo service klipper start
```
For multiple MCUs without unique IDs (common on CH340 USB chips), use `ls /dev/serial/by-path/*` instead. This also fixes the "device changes to /dev/ttyUSB1 after restart" problem.

## "make flash" Doesn't Work
Stop Klipper (`sudo service klipper stop`), make sure nothing else connects to the device, verify FLASH_DEVICE. If it still fails, check the config directory for board-specific flash instructions, or flash manually with avrdude/bossac (see Bootloaders doc).

## Serial Baud Rate
Recommended/default is **250000** — works on all supported boards. Ignore online guides recommending different rates. The OctoPrint web-page baud rate is unrelated to Klipper's internal MCU baud rate — always set OctoPrint to 250000. Changing the real rate requires reconfiguring in `make menuconfig`, recompiling, reflashing, and updating `[mcu] baud:`.

## Host Hardware
Recommended: RPi Zero2W, Pi 3, Pi 4, or Pi 5. Pi 1/2/Zero1 lack processing power — print stalls common, not recommended. Minimum requirement is double-precision floating-point hardware. On shared/desktop machines, real-time scheduling matters — heavy concurrent tasks (defrag, 3D rendering, swapping) can cause print errors. Some distros enable ModemManager which disrupts serial → may need disabling (cause of random "Lost communication with MCU").

## Why Can't I Move a Stepper Before Homing?
Safety — to avoid commanding the head into the bed/wall. After homing, Klipper verifies each move against position_min/max. M84/M18 disables motors → must re-home before moving. For movement after print/cancel, use slicer custom gcode or OctoPrint GCODE scripts. For homing-process movement, use safe_z_home or homing_override. For diagnostics, use force_move.

## Why is Z position_endstop 0.5 in Default Configs?
On cartesian printers, Z position_endstop = nozzle-to-bed distance when the endstop triggers. Prefer a Z-max endstop homing away from the bed. If homing toward the bed, position the endstop to trigger while the nozzle is still slightly away — so homing stops before the nozzle touches.

## Screeching Noise Homing Z (after Marlin conversion)
First verify stepper config (Config Checks doc). If it persists, reduce `max_z_velocity`. Marlin caps at ~10000 steps/sec; Klipper achieves much higher rates, but the motor may lack torque at those speeds. High Z gearing or high microsteps → actual max_z_velocity may be lower than Marlin's configured value.

## TMC Driver Turns Off Mid-Print
If using TMC2208/TMC2224 in standalone mode, update to the latest Klipper (a stealthchop workaround was added mid-March 2020).

## Random "Lost Communication with MCU" Errors
Commonly USB hardware issues:
- Use a good quality, secure USB cable.
- On RPi: use a good power supply and good USB power cable. Fix any "under voltage" warnings.
- Don't overload the printer's PSU (power fluctuations reset the MCU USB chip).
- Check stepper/heater/other wires aren't crimped or frayed (movement stresses faulty wires).
- Mixed 5V supplies (printer PSU + host 5V) can cause USB noise — configure the MCU to use power from only one source, or modify the USB cable to not carry 5V between host and MCU.

(Same troubleshooting applies to "RPi keeps rebooting during prints" — usually voltage fluctuations.)

## Will Heaters Stay On if the Pi Crashes?
No — designed against this. The host must reconfirm each enabled heater every 3 seconds; if the MCU doesn't get confirmation within 3s, it enters "shutdown" (turns off all heaters and steppers). MCU also shuts down if temperature exits the configured min_temp/max_temp range. Host-side verify_heater code checks heaters and sensors function correctly.

## Marlin Pin Number → Klipper Pin Name
Mapping in `config/sample-aliases.cfg`. Klipper uses the MCU's standard hardware pin names (PA4, PC7, PD2) rather than Arduino's incrementing numbers (D23, A14) — Arduino numbers don't translate consistently across boards (D21 is PD0 on one board, PC7 on another). sample-aliases.cfg uses "ar" prefix for digital (D23 → ar23) and "analog" for analog (A14 → analog14).

## Do I Have to Wire to a Specific Pin Type?
- **ADC/Analog pins:** Required for thermistors and analog sensors. Wrong pin → "Not a valid ADC pin".
- **PWM pins:** Klipper uses software PWM by default — heaters/fans can go on any GPIO. Only need a hardware-PWM-capable pin if you set `hardware_pwm: True` (else "Not a valid PWM pin").
- **IRQ/Interrupt pins:** Never needed — Klipper doesn't use hardware interrupts on IO pins.
- **SPI pins:** Hardware SPI needs SPI-capable pins; software SPI works on any GPIO.
- **I2C pins:** Must use I2C-capable pins.
- **Anything else** (steppers, heaters, fans, Z probes, servos, LEDs, LCDs, TMC UART): any GPIO.

## Cancel an M109/M190 "Wait for Temperature"
Issue `M112` (shutdown + OctoPrint disconnect). Reconnect, then `FIRMWARE_RESTART` to clear the error. The previous heat request is canceled.

## Detecting Lost Steps
Home, `GET_POSITION`, run the print/test moves, home again, `GET_POSITION`, compare the `mcu:` line values. Useful for tuning currents/accel/speed without printing. Endstops trigger at slightly varying positions, so a couple microsteps difference is normal. A stepper only loses steps in increments of 4 full steps (at 16 microsteps, a lost step = mcu counter off by a multiple of 64 microsteps).

## Why Does Klipper Report Errors? I Lost My Print!
By design — Klipper alerts you to detected problems so the underlying issue can be fixed, rather than silently producing low-quality prints. It auto-works-around transient issues (retransmits comms errors, buffers commands) but reports unrecoverable errors, invalid actions, or impossible tasks. These situations carry high risk of bad prints, so alerting empowers you to fix the root cause.

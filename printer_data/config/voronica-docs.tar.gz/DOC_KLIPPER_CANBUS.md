# Klipper CANBUS Guide
*Source: klipper3d.org/CANBUS.html — Full official documentation*
*Relevant to Voronica: Manta M8P V2 in USB-to-CAN bridge mode, EBBCan on CAN bus*

---

## Supported Chips
CAN bus is supported on stm32, SAME5x, and rp2040 chips. Board must have a CAN transceiver.

---

## Host CAN Interface Setup

Create `/etc/network/interfaces.d/can0`:
```
allow-hotplug can0
iface can0 can static
    bitrate 1000000
    up ip link set $IFACE txqueuelen 128
```

`allow-hotplug` is important for USB-to-CAN bridge mode so the interface restores after MCU reset.

Recommended bitrate: **1000000 (1Mbit)** especially when using USB-to-CAN bridge mode.

---

## Terminating Resistors

CAN bus requires exactly TWO 120 ohm resistors between CANH and CANL — one at each end of the bus.

To verify: remove printer power, measure resistance between CANH and CANL with multimeter — should read ~60 ohms (two 120Ω in parallel).

---

## Finding canbus_uuid for New Devices

Run on host:
```
~/klippy-env/bin/python ~/klipper/scripts/canbus_query.py can0
```

Output example:
```
Found canbus_uuid=11aa22bb33cc, Application: Klipper
```

**Note:** Tool only reports UNINITIALIZED devices. Once Klipper connects, device no longer appears in list.

---

## Configuring in printer.cfg

```
[mcu]
canbus_uuid: cccdb0d58c74    # Voronica Manta M8P

[mcu EBBCan]
canbus_uuid: 6a4c8547c5af    # Voronica EBBCan
```

---

## USB to CAN Bus Bridge Mode

Allows a single MCU to act as both USB-to-CAN adapter AND a Klipper node. This is what Voronica uses — the Manta M8P acts as the CAN bridge.

**Key notes for bridge mode:**
- MCU appears as "USB CAN adapter" in Linux, NOT as a USB serial device
- Bridge MCU will NOT appear in `ls /dev/serial/by-id`
- Must be configured with `canbus_uuid:`, not `serial:` in printer.cfg
- Bridge board is NOT actually on the CAN bus — messages to/from it are not seen by other adapters
- Linux CAN bus speed set in interfaces.d is ignored by Klipper — frequency set during `make menuconfig`
- When bridge MCU resets, Linux disables the can0 interface — `allow-hotplug` in interfaces.d handles recovery
- Bandwidth for bridge MCU AND all CAN bus devices is limited by CAN bus frequency — use 1Mbit
- Bridge mode requires at least one other node on the CAN bus (EBBCan in Voronica's case)

---

## CAN Bus Troubleshooting Quick Reference

See also: klipper3d.org/CANBUS_Troubleshooting.html

**No UUID found by canbus_query.py:**
- Check wiring (CANH/CANL, power, ground)
- Verify termination resistors (~60Ω measured)
- Verify bitrate matches (1Mbit)
- Device may already be initialized (running Klipper) — won't appear in query

**"Unable to connect" errors:**
- Check CAN interface is up: `ip link show can0`
- Check bitrate: `ip -details link show can0`
- Check errors: `cat /proc/net/can/stats`

**Status monitoring:**
```
printer["canbus_stats mcu"].bus_state     # "active" | "warn" | "passive" | "off"
printer["canbus_stats mcu"].rx_error      # receive error count
printer["canbus_stats mcu"].tx_error      # transmit error count
```

---

## Voronica CAN Bus Setup Summary

| Device | Connection | UUID | Interface |
|---|---|---|---|
| Manta M8P V2 | USB to RPi CM4 (bridge mode) | cccdb0d58c74 | [mcu] |
| BTT EBB36 | CAN bus (2-wire) | 6a4c8547c5af | [mcu EBBCan] |
| Beacon RevH | USB serial (separate) | /dev/serial/by-id/... | [beacon] serial: |

CAN bus speed: 1Mbit (set in firmware flash, not in can0 config for bridge mode)

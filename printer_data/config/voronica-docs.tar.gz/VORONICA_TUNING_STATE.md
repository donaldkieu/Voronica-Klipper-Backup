# Vorovina — Tuning State
*Update this file whenever a value is confirmed changed. Re-upload to the Claude Project.*
*Changelog: 2026-08-27 — Corrected retract_length to match live printer.cfg (0.4mm, not 0.2mm as previously tracked — doc was stale). Logged new open issue: extruder motor free-spin fault under investigation. Confirmed extruder autotune tuning_goal already correctly set to performance.*

---

## Input Shaper — Current

| Axis | Shaper | Frequency | Damping Ratio | Date Confirmed |
|---|---|---|---|---|
| X | MZV | 132.8 Hz | 0.070 | 2026-07-24 |
| Y | MZV | 84.8 Hz | 0.038 | 2026-07-24 |

**Accelerometer used:** Beacon3D RevH (rigidly mounted on SLM aluminum carriage, co-located with hotend)
**Test method:** Klippain ShakeTune AXES_SHAPER_CALIBRATION
**Notes:** Previous values (X 107.2Hz / Y 82.6Hz) were measured with ADXL345 on EBB36. New values reflect rigid SLM mount — Beacon closer to nozzle tip, more accurate. X frequency increase (107→132Hz) consistent with reduced toolhead compliance from rigid mount.

---

## Pressure Advance — Current

| Material | Profile | PA Value | Method | Date |
|---|---|---|---|---|
| All (global) | — | 0.02 (commented out in cfg) | Hardware-dominated — stable across materials | 2026-07-24 |

**Notes:** PA is hardware-dominated by WWBMG + RIGDA V2 + Dragon UHF Mini direct drive. Stable across materials, speeds, and accels. No per-material tuning required except TPU/highly viscous filaments. PA line commented out in printer.cfg — being set per-filament profile in OrcaSlicer or relying on slicer PA.

---

## Belt Tension / motors-sync

| Axis | Phase Offset | Date | Notes |
|---|---|---|---|
| X | 160 | 2026-06-30 | Confirmed from session |
| Y | 256 | 2026-06-30 | Confirmed from session |

**accel_chip:** beacon (intentional — Beacon on rigid SLM carriage preferred over ADXL345 on EBB36)
**Notes:** Re-run SYNC_MOTORS after any belt tension change or motor swap.

---

## Beacon Calibration

| Model | Temp at Cal | Offset | Date |
|---|---|---|---|
| default | 63.1°C | 0.00000 | unknown |
| cold | 30.7°C | 0.00000 | unknown |

**Backlash compensation:** 0.06mm
**Thermal Z offset in PRINT_START:** +0.07mm (confirmed from live macros.cfg 2026-07-24)
**Notes:** Beacon plugin v2.0.0-31 active. v2.0.0-34 pending (fixes non_critical_recon_event crash). Recalibrate after update. Beacon now on rigid SLM aluminum mount — recalibration recommended after any further toolhead mechanical changes.

---

## PID Tuning

| Heater | Target | Kp | Ki | Kd | Date |
|---|---|---|---|---|---|
| Extruder | 290°C | 21.057 | 1.290 | 85.935 | 2026-08-27 (confirmed from live SAVE_CONFIG block) |
| Bed | 110°C | 68.581 | 2.284 | 514.789 | 2026-08-27 (confirmed from live SAVE_CONFIG block) |

---

## Velocity & Acceleration

| Parameter | Value | Date | Notes |
|---|---|---|---|
| max_velocity | 2000 mm/s | 2026-08-27 | Confirmed from live printer.cfg |
| max_accel | 50000 mm/s² | 2026-08-27 | Confirmed from live printer.cfg |
| square_corner_velocity | 20 mm/s | 2026-07-24 | Confirmed from live printer.cfg |

---

## Firmware Retraction

| Parameter | Value | Date | Notes |
|---|---|---|---|
| retract_length | **0.4mm** | 2026-08-27 | **Correction:** live printer.cfg shows 0.4mm — this doc previously tracked 0.2mm from 2026-07-24 ("reduced to address divots"). Conflict unresolved — confirm which value you actually intend; live value used as working answer per current protocol. |
| retract_speed | 45mm/s | 2026-08-27 | Confirmed from live printer.cfg |
| unretract_extra_length | 0mm | 2026-08-27 | Confirmed from live printer.cfg |
| unretract_speed | 30mm/s | 2026-08-27 | Confirmed from live printer.cfg |

---

## Extruder Calibration

| Parameter | Value | Notes |
|---|---|---|
| rotation_distance | 22.6789511 | WWBMG / 50:6 / RIGDA V2 — confirmed live 2026-08-27 |
| gear_ratio | 50:6 | Uses 6T motor pinion (off-spec vs Bondtech's validated 8T/10T for RIDGA V2) |
| run_current | 0.7A (config) / temporarily raised to 0.75A during troubleshooting — see Open Issues | Motor: ldo-36sth20-1004ahg, rated holding_torque 0.10Nm, max_current 1.0A |
| autotune tuning_goal | performance (confirmed correct in live steppers.cfg, 2026-08-27) | Correctly avoids default "silent" goal, which would be wrong for this low-torque motor |
| E steps verified | unknown | — |

---

## Flex Plates

*Add your plates here as you define them.*

| Index | Name | Z Offset | Notes |
|---|---|---|---|
| — | — | — | — |

---

## Open Issues / Things to Revisit

- [ ] **NEW (2026-08-27):** Extruder motor does not spin freely even unloaded, outside the housing, at 0.7A — rules out gear mesh/housing/lubrication/filament as cause. Suspected electrical/mechanical fault (winding, connector, bearing). 0.75A masks the symptom but is not a confirmed fix. Pending: hand-turn test with driver disabled, phase continuity check, `DUMP_TMC STEPPER=extruder` for driver-reported faults.
- [ ] **NEW (2026-08-27):** retract_length conflict — this doc said 0.2mm, live config says 0.4mm. Needs your confirmation of intended value.
- [ ] Beacon update pending: v2.0.0-31 → v2.0.0-34 — recalibrate after
- [ ] Unsafe shutdown count at 400 — investigate cause (power loss? kernel panic?)
- [ ] PA not explicitly set in printer.cfg — confirm OrcaSlicer per-filament PA is covering this
- [ ] Confirm flex plate offsets and document above
- [ ] Re-run PID calibration after rigid SLM hotend mount — thermal mass may have changed
- [ ] Confirm motors-sync phase offsets still valid after toolhead hardware changes (2026-07-24)
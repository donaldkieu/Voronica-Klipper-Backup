# Beacon3D — Documentation Reference
*Extracted from docs.beacon3d.com and github.com/beacon3d/beacon_klipper*
*Applicable to: Beacon RevH, firmware 2.1.0, beacon_klipper v2.0.0-31+*

---

## [beacon] Config Section

```
[beacon]
serial:                             # USB path: /dev/serial/by-id/usb-Beacon_Beacon_RevH_...-if00
speed: 5                            # mm/s — Z probing dive speed
lift_speed: 5                       # mm/s — Z lift speed after probe
x_offset: 0                         # mm — X offset of beacon from nozzle
y_offset: 23                        # mm — Y offset (Voronica: Beacon is 23mm behind nozzle)
mesh_main_direction: x              # x|y — primary travel direction during mesh
mesh_overscan: -1                   # mm — direction change distance at line ends; -1 = auto
mesh_cluster_size: 1                # mm — radius of mesh grid point clusters
mesh_runs: 1                        # number of passes during mesh scan

backlash_comp: 0.06                 # mm — backlash compensation (Voronica confirmed value)

# Contact mode settings
contact_max_hotend_temperature: 180 # °C — max hotend temp for contact probing
                                    # increase to probe at print temps (up to ~220°C is safe for most surfaces)
contact_sensitivity: 0              # 0–3 — noise tolerance for contact; 3 = most tolerant
contact_latency_min: 0              # minimum latency contact is allowed to advance

# Homing configuration
home_xy_position: 150, 150          # X, Y — position for Z homing
home_z_hop: 5                       # mm — Z hop before homing
home_z_hop_speed: 50                # mm/s
home_xy_move_speed: 500             # mm/s
home_y_before_x: True               # if True, Y homes before X when using beacon safe_z_home
home_method: contact                # contact|proximity — method for initial home
home_method_when_homed: proximity   # method after initial home (faster)
home_autocalibrate: unhomed         # unhomed|never|always
                                    # unhomed = contact calibrates on first home only

# Accelerometer (RevH only)
accel_scale: 16g                    # 16g|8g|4g|2g — sensitivity (16g default is fine for most)
accel_axes_map: -x, -y, z          # Voronica mapping

# Other
is_non_critical: True               # allows beacon to disconnect/reconnect without errors
default_model_name: default         # which model loads on startup
z_settling_time: 5                  # ms — Z settle delay before proximity measurements
cal_nozzle_z: 0.1                   # expected nozzle offset after manual Z calibration
```

---

## Homing with Beacon

### Contact Mode (initial home / calibration)
```
G28 Z METHOD=CONTACT CALIBRATE=1
# - Moves to home_xy_position
# - Uses nozzle contact to find Z=0
# - Calibrates a new proximity scan model
# - Use on first home of session, or after any mechanical change

G28 Z METHOD=CONTACT CALIBRATE=0
# - Uses contact to find Z=0
# - Skips model calibration (faster)
# - Use after QGL or bed mesh when position is already known
```

### Proximity Mode (fast subsequent homing)
```
G28 Z METHOD=PROXIMITY
# - Uses inductive scan model for Z homing
# - Faster than contact, requires a calibrated model
# - Automatically used after first contact home (home_method_when_homed: proximity)
```

### Requirements for Contact Mode
- Beacon mount must be ~3mm higher than nozzle tip
- Metal must be present in bed stack
- Materials on top of metal must be ≤3–4mm thick
- `zero_reference_position` must be set in `[bed_mesh]` (Voronica: 150, 150)
- `contact_max_hotend_temperature` must be set to enable hot probing

---

## Commands Reference

### Calibration
```
BEACON_CALIBRATE
# Manual contact calibration — interactive, step through with ACCEPT/ABORT
# Creates/updates the 'default' model
# Best practice: calibrate hot (bed at print temp, beacon soaked)

BEACON_AUTO_CALIBRATE [SPEED=<>] [ACCEL=<>] [RETRACT=<>] [SAMPLES=<>]
    [SAMPLES_TOLERANCE=<>] [SAMPLES_TOLERANCE_RETRIES=<>] [SKIP_MODEL_CREATION=<1>]
# Automated version: uses contact to find Z=0, then runs full calibration
# SKIP_MODEL_CREATION=1: only sets Z offset, skips scan model calibration
# Runs at current X, Y position — move to home_xy_position first

BEACON_POKE [SPEED=<>] [BOTTOM=<z>] [TOP=<z>]
# Contact with safety features — use for testing new surfaces/setups
# Has extra safeguards vs BEACON_CALIBRATE, recommended for experimentation
```

### Probing
```
PROBE [PROBE_SPEED=<>] [LIFT_SPEED=<>] [PROBE_METHOD=contact|proximity]
# Single Z probe operation

PROBE_ACCURACY [PROBE_SPEED=<>] [SAMPLES=<n>] [LIFT_SPEED=<>] [SAMPLE_RETRACT_DIST=<>]
# Multiple probes — reports mean, median, range, std deviation
# Use to verify probe repeatability after changes

BEACON_ESTIMATE_BACKLASH
# Estimates backlash compensation value
# Run after any hardware change, update backlash_comp in config
```

### Bed Mesh
```
BED_MESH_CALIBRATE [METHOD=beacon] [ADAPTIVE=1] [RUNS=<n>]
    [PROBE_METHOD=contact|proximity] [CLUSTER_SIZE=<mm>]
    [SPEED=<>] [PROBE_SPEED=<>]
# METHOD=beacon is default (proximity scan mode)
# ADAPTIVE=1 uses KAMP to limit mesh to print area
# PROBE_METHOD=contact runs stop-and-probe mesh (slower, more accurate)
```

### Models
```
BEACON_MODEL_LIST
# Lists all available models and which is active
# Example output: - default [active] | - cold

BEACON_MODEL_SELECT NAME=<name>
# Activate a specific model for the session

BEACON_MODEL_SAVE NAME=<name>
# Save active model as named model — requires SAVE_CONFIG to persist

BEACON_MODEL_REMOVE NAME=<name>
# Remove a model — requires SAVE_CONFIG to persist

Z_OFFSET_APPLY_PROBE
# Apply current baby-step Z offset into the active Beacon model
# Requires SAVE_CONFIG — use after dialing in first layer
```

### Diagnostics
```
BEACON_QUERY
# Query beacon signal and status

ACCELEROMETER_QUERY CHIP=beacon
# Check accelerometer readings from Beacon RevH

MEASURE_AXES_NOISE CHIP=beacon
# Measure noise floor of beacon accelerometer

TEST_RESONANCES AXIS=X CHIP=beacon
TEST_RESONANCES AXIS=Y CHIP=beacon
# Use beacon as accelerometer for resonance testing
# Can compare with CHIP=adxl345 for cross-validation
```

---

## Multiple Models Workflow

Useful for different bed surfaces or temperatures:

```
# After dialing in a surface with babystep:
Z_OFFSET_APPLY_PROBE            # apply offset to active model
BEACON_MODEL_SAVE NAME=pei_hot  # save as named model
SAVE_CONFIG                     # persist to config

# Switch models:
BEACON_MODEL_SELECT NAME=pei_cold
BEACON_MODEL_SELECT NAME=default
```

---

## Important Notes

- **Temperature compensation:** Model is calibrated at a specific temperature. The plugin compensates relative to model_temp. For chambers >65°C, calibrate hot for best accuracy.
- **Backlash:** After any mechanical change (belt tightening, hardware swap), re-run `BEACON_ESTIMATE_BACKLASH` and update `backlash_comp`.
- **After Beacon plugin update:** Recalibrate with `BEACON_AUTO_CALIBRATE` — plugin updates can change model behaviour.
- **`is_non_critical: True`:** Allows USB disconnect/reconnect without Klipper errors. Safe to leave enabled.
- **Supported firmware:** Only Klipper and Kalico are supported. No Marlin support.
- **Temperature limits:** Sensor rated to 120°C coil, 110°C amplifier. LED powers off >90°C, accelerometer powers off >102°C automatically.

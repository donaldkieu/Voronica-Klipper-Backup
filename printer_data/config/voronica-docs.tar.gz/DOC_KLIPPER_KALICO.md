# Klipper/Kalico — Config & G-Code Reference
*Extracted from official Klipper documentation: klipper3d.org*
*Supplemented with Kalico-specific additions from github.com/KalicoCrew/kalico*
*For Voronica — cross-reference with working config before suggesting any change*

---

## Pin Naming Conventions
- `PA4` — hardware pin name
- `!PA4` — inverted polarity (active low)
- `^PA4` — hardware pull-up resistor enabled
- `~PA4` — hardware pull-down resistor enabled
- `EBBCan:PA4` — pin on secondary MCU named EBBCan

---

## [mcu]
```
[mcu]
canbus_uuid:        # CAN bus chip identifier — use instead of serial for CAN
serial:             # Serial port path — use instead of canbus_uuid for USB/serial
canbus_interface:   # CAN network interface, default: can0
restart_method:     # arduino | cheetah | rpi_usb | command
```

---

## [printer]
```
[printer]
kinematics: corexy              # cartesian|corexy|corexz|delta|none|etc
max_velocity:                   # mm/s — required
max_accel:                      # mm/s² — required
max_z_velocity:                 # mm/s — limits Z axis speed separately
max_z_accel:                    # mm/s²
minimum_cruise_ratio: 0.5       # 0.0–1.0 — replaces deprecated max_accel_to_decel
                                # enforces minimum cruise distance on short moves
square_corner_velocity: 5.0     # mm/s — toolhead speed through 90° corners
```
**Runtime:** `SET_VELOCITY_LIMIT VELOCITY=<> ACCEL=<> MINIMUM_CRUISE_RATIO=<> SQUARE_CORNER_VELOCITY=<>`
**Deprecated:** `max_accel_to_decel` / `ACCEL_TO_DECEL` — do not use

---

## [stepper_x/y/z] — Common Parameters
```
step_pin:
dir_pin:                        # add ! to invert direction
enable_pin:                     # add ! for active-low enable (most boards)
rotation_distance:              # mm per full motor revolution (after gear_ratio)
microsteps:                     # 8|16|32|64|128|256
full_steps_per_rotation: 200    # 200 for 1.8°, 400 for 0.9°
gear_ratio:                     # e.g. 80:16 or 50:6 — optional
step_pulse_duration:            # default 100ns for TMC SPI/UART, 2µs otherwise
endstop_pin:                    # or probe:z_virtual_endstop for Beacon
position_min: 0
position_endstop:               # required for X/Y/Z on cartesian/corexy
position_max:                   # required
homing_speed: 5.0               # mm/s
homing_retract_dist: 5.0        # mm — set to 0 for Beacon contact Z homing
homing_retract_speed:           # defaults to homing_speed
second_homing_speed:            # defaults to homing_speed/2
homing_positive_dir:            # true = home toward max, false = toward min
```

---

## [tmc5160] — SPI Mode (X/Y motors on Voronica)
```
[tmc5160 stepper_x]
cs_pin:                         # SPI chip select pin
spi_software_sclk_pin:
spi_software_mosi_pin:
spi_software_miso_pin:
# OR: spi_bus: spiX for hardware SPI
run_current:                    # RMS amps
sense_resistor: 0.075           # Voronica value — DO NOT use 0.110 (that's TMC2209)
interpolate: true               # 256 microstep interpolation
stealthchop_threshold: 0        # 0 = always spreadcycle (performance)
                                # 999999 = always stealthchop (quiet)
                                # velocity in mm/s to switch at
driver_TBL:                     # blanking time — set by autotune, do not guess
driver_TOFF:                    # off time — set by autotune, do not guess
driver_HEND:                    # hysteresis end — set by autotune
driver_HSTRT:                   # hysteresis start — set by autotune
```
**Runtime commands:**
```
DUMP_TMC STEPPER=stepper_x              # dump all registers
SET_TMC_CURRENT STEPPER=stepper_x CURRENT=<amps>
                                        # Note: after SET_TMC_CURRENT on TMC5160 with
                                        # stealthchop, hold stepper still >130ms for AT#1
                                        # calibration — not applicable here (stealthchop OFF)
INIT_TMC STEPPER=stepper_x             # re-initialise driver from config
SET_TMC_FIELD STEPPER=<> FIELD=<> VALUE=<>  # low-level register write — use carefully
```

---

## [tmc2209] — UART Mode (Z motors + extruder on Voronica)
```
[tmc2209 stepper_z]
uart_pin:                       # single-wire UART pin
run_current:                    # RMS amps
sense_resistor: 0.110           # Voronica Z/extruder value
interpolate: true
stealthchop_threshold: 999999   # Z motors: always stealthchop
hold_current:                   # optional — lower current when idle
                                # WARNING: do not use with sensorless homing
driver_SGTHRS:                  # stallguard threshold — only for sensorless homing
```

---

## [autotune_tmc] — klipper_tmc_autotune Plugin
```
[autotune_tmc stepper_x]
motor: ldo-42sth48-2504ah       # must match motor_database entry exactly
tuning_goal: performance        # auto | silent | performance
voltage: 48                     # supply voltage in volts
```
**Valid motor names for Voronica:**
- `ldo-42sth48-2504ah` — X/Y (48V)
- `moons-ms17hd6p420i` — Z (24V)
- `ldo-36sth20-1004ahg` — extruder (24V)

**Runtime:** `AUTOTUNE_TMC STEPPER=<name>` — re-run autotune for one stepper
**Motor database:** https://github.com/andrewmcgr/klipper_tmc_autotune/tree/main/motor_database

---

## [extruder]
```
[extruder]
step_pin:
dir_pin:
enable_pin:
full_steps_per_rotation: 200
microsteps:
gear_ratio:                     # e.g. 50:6
rotation_distance:              # mm of filament per full motor revolution
nozzle_diameter:
filament_diameter: 1.750
heater_pin:
sensor_type:                    # MAX31865 | Generic 3950 | ATC Semitec 104GT-2 | etc
sensor_pin:
min_temp:
max_temp:
min_extrude_temp: 170
max_extrude_cross_section: 5    # mm² — limits extrusion rate on small moves
max_extrude_only_distance: 150  # mm — max retract/load distance
pressure_advance:               # PA value — set per material
pressure_advance_smooth_time: 0.040

# For MAX31865 RTD sensor:
spi_bus:                        # or spi_software_*
rtd_nominal_r: 100              # PT100 = 100
rtd_reference_r: 430            # reference resistor value
rtd_num_of_wires: 2             # 2 | 3 | 4
```
**Runtime:**
```
SET_PRESSURE_ADVANCE ADVANCE=<value> [EXTRUDER=<name>] [SMOOTH_TIME=<sec>]
SET_EXTRUDER_ROTATION_DISTANCE EXTRUDER=<name> DISTANCE=<mm>
```

---

## [heater_bed]
```
[heater_bed]
heater_pin:
sensor_pin:
sensor_type: Generic 3950
max_power: 1.0
min_temp:
max_temp:
```
**Runtime:** `PID_CALIBRATE HEATER=heater_bed TARGET=<temp>` then `SAVE_CONFIG`

---

## [input_shaper]
```
[input_shaper]
shaper_freq_x:                  # Hz — resonant frequency of X axis
shaper_freq_y:                  # Hz
shaper_type_x: mzv              # zv|mzv|zvd|ei|2hump_ei|3hump_ei
shaper_type_y: mzv
damping_ratio_x:                # Kalico extension — not in standard Klipper
damping_ratio_y:                # measured by ShakeTune, improves IS accuracy
```
**Runtime:**
```
SET_INPUT_SHAPER SHAPER_FREQ_X=<> SHAPER_FREQ_Y=<> SHAPER_TYPE_X=<> SHAPER_TYPE_Y=<>
SHAPER_CALIBRATE                # built-in Klipper IS calibration (ShakeTune replaces this)
TEST_RESONANCES AXIS=X [CHIP=adxl345|beacon]
TEST_RESONANCES AXIS=Y [CHIP=adxl345|beacon]
MEASURE_AXES_NOISE [CHIP=<name>]
ACCELEROMETER_QUERY [CHIP=<name>]
```

---

## [resonance_tester]
```
[resonance_tester]
accel_chip: adxl345             # accelerometer to use
probe_points:
    150, 150, 20                # X, Y, Z to probe at — use center of bed
accel_per_hz: 100               # acceleration per Hz during sweep
sweeping_accel: 400             # acceleration during new sweeping test mode
sweeping_period: 0              # 0 = auto
```

---

## [adxl345]
```
[adxl345]
cs_pin:
spi_software_sclk_pin:
spi_software_mosi_pin:
spi_software_miso_pin:
axes_map: x,z,-y                # Voronica mapping — reorder/invert to match machine axes
```

---

## [bed_mesh]
```
[bed_mesh]
speed: 300                      # mm/s during mesh movement
mesh_min:                       # X, Y — first probe point
mesh_max:                       # X, Y — last probe point
probe_count: 30, 30             # X, Y number of points
algorithm: bicubic              # lagrange (up to 6×6) | bicubic (larger grids)
zero_reference_position: 150, 150   # normalize mesh to this position
                                    # should match home_xy_position
```
**Runtime:**
```
BED_MESH_CALIBRATE [METHOD=beacon] [ADAPTIVE=1] [RUNS=<n>]
BED_MESH_CLEAR
BED_MESH_PROFILE LOAD=<name>
BED_MESH_PROFILE SAVE=<name>
BED_MESH_PROFILE REMOVE=<name>
BED_MESH_OUTPUT                 # print mesh to console
BED_MESH_MAP                    # output mesh as JSON
BED_MESH_OFFSET [X=<>] [Y=<>]  # apply XY offset to active mesh
```

---

## [quad_gantry_level]
```
[quad_gantry_level]
gantry_corners:                 # two diagonal corners of gantry travel
    -60,-10
    360,370
points:                         # four probe points (one per Z motor)
    50,25
    50,225
    250,225
    250,25
speed: 500
horizontal_move_z: 3
retries: 20
retry_tolerance: 0.0075
max_adjust: 10
```
**Runtime:** `QUAD_GANTRY_LEVEL [HORIZONTAL_MOVE_Z=<>] [RETRY_TOLERANCE=<>]`

---

## [homing_override]
```
[homing_override]
axes: xyz                       # which axes this override applies to
set_position_x:                 # optional — set assumed position before moves
set_position_y:
set_position_z:
gcode:
    # Your custom homing gcode here
    # Note: homed_axes is NOT updated until after the macro completes
    # during a full G28. It IS valid during single-axis G28 calls.
```

---

## [firmware_retraction]
```
[firmware_retraction]
retract_length: 0.4             # mm
retract_speed: 40               # mm/s
unretract_extra_length: 0       # mm added on unretract
unretract_speed: 35             # mm/s
```
**Runtime:**
```
SET_RETRACTION [RETRACT_LENGTH=<>] [RETRACT_SPEED=<>] [UNRETRACT_SPEED=<>]
GET_RETRACTION
G10                             # firmware retract
G11                             # firmware unretract
```

---

## [fan] / [heater_fan] / [controller_fan] / [fan_generic]
```
[fan]                           # part cooling fan — controlled by M106/M107
pin:
max_power: 1.0
shutdown_speed: 0.0
cycle_time: 0.01                # 100Hz — PWM frequency
hardware_pwm: false
kick_start_time: 0.1            # seconds of full power on startup
off_below: 0.0                  # min speed before fan turns off

[heater_fan name]               # runs when heater is above heater_temp
pin:
heater:                         # extruder | heater_bed | etc
heater_temp: 50.0               # °C — temperature to activate fan
fan_speed: 1.0
tachometer_pin:                 # optional — requires ^ pullup
tachometer_ppr: 2               # pulses per revolution
tachometer_poll_interval: 0.0015

[controller_fan name]           # runs when any stepper is active
pin:
stepper:                        # stepper_x, stepper_y, stepper_z — comma separated
fan_speed: 1.0
idle_timeout: 30                # seconds to keep running after stepper stops
idle_speed: 0                   # speed when idle (0 = off)

[fan_generic name]              # manually controlled generic fan
pin:
```
**Runtime:**
```
SET_FAN_SPEED FAN=<name> SPEED=<0.0-1.0>
M106 S<0-255>                   # part cooling fan
M107                            # part cooling fan off
```

---

## [neopixel]
```
[neopixel sb_leds]
pin:
chain_count: 3
color_order: GRBW               # GRB | RGB | GRBW | RGBW
initial_RED: 1.0
initial_GREEN: 1.0
initial_BLUE: 1.0
initial_WHITE: 0.0
```
**Runtime:**
```
SET_LED LED=sb_leds RED=<> GREEN=<> BLUE=<> WHITE=<> [INDEX=<n>] [TRANSMIT=0|1]
SET_LED_EFFECT EFFECT=<name>    # from led_effect plugin
STOP_LED_EFFECTS               # stop all active led_effect animations
```

---

## [save_variables]
```
[save_variables]
filename: ~/variables.cfg       # path to persistent variable storage file
```
**Runtime:** `SAVE_VARIABLE VARIABLE=<name> VALUE=<value>`
**Access in macros:** `printer.save_variables.variables.<name>`

---

## [gcode_macro]
```
[gcode_macro NAME]
description: Human readable description
rename_existing: ORIGINAL_NAME  # rename the command being replaced
variable_<name>: <value>        # persistent macro variable
gcode:
    {% set val = params.PARAM|default(0)|int %}   # parameter with default
    {% set x = printer.toolhead.position.x %}      # access printer state
    { action_respond_info("Message") }             # print to console
    { action_raise_error("Error") }                # raise error and stop
```

---

## Standard G-Code Commands
```
G0/G1 [X<>] [Y<>] [Z<>] [E<>] [F<mm/min>]  # move (F is mm/min, not mm/s — multiply by 60)
G4 P<milliseconds>              # dwell/wait
G28 [X] [Y] [Z]                # home axes
G90                             # absolute positioning
G91                             # relative positioning
G92 [X<>] [Y<>] [Z<>] [E<>]   # set position
M82                             # absolute extrusion
M83                             # relative extrusion
M84 / M18                       # disable steppers
M104 S<temp>                    # set hotend temp (no wait)
M109 S<temp>                    # set hotend temp and wait
M140 S<temp>                    # set bed temp (no wait)
M190 S<temp>                    # set bed temp and wait
M106 S<0-255>                   # part cooling fan speed
M107                            # part cooling fan off
M112                            # emergency stop
M114                            # get current position
M115                            # get firmware version
M204 S<mm/s²>                  # set acceleration
M220 S<percent>                 # speed factor override
M221 S<percent>                 # extrude factor override
M400                            # wait for moves to complete
```

---

## Extended G-Code Commands (Klipper-specific)
```
SAVE_CONFIG                     # write pending changes to printer.cfg and restart
RESTART                         # restart Klipper host
FIRMWARE_RESTART                # restart Klipper + reinitialise MCUs
STATUS                          # report Klipper state

GET_POSITION                    # report MCU stepper positions — use to detect skipping
SET_GCODE_OFFSET Z=<>           # set absolute Z offset
SET_GCODE_OFFSET Z_ADJUST=<>    # adjust Z offset by delta
SET_GCODE_OFFSET Z=0            # reset Z offset
SAVE_GCODE_STATE NAME=<name>    # save current motion state
RESTORE_GCODE_STATE NAME=<name> [MOVE=0|1] [MOVE_SPEED=<>]

SET_VELOCITY_LIMIT VELOCITY=<> ACCEL=<> MINIMUM_CRUISE_RATIO=<> SQUARE_CORNER_VELOCITY=<>

PID_CALIBRATE HEATER=<name> TARGET=<temp>   # PID autotune
TEMPERATURE_WAIT SENSOR=<name> MINIMUM=<> [MAXIMUM=<>]
SET_HEATER_TEMPERATURE HEATER=<name> TARGET=<temp>
TURN_OFF_HEATERS
SET_IDLE_TIMEOUT TIMEOUT=<seconds>

STEPPER_BUZZ STEPPER=<name>     # verify stepper wiring
QUERY_ENDSTOPS
SET_STEPPER_ENABLE STEPPER=<name> ENABLE=0|1

RESPOND MSG="<message>"         # print message to console
UPDATE_DELAYED_GCODE ID=<name> DURATION=<seconds>  # trigger/cancel delayed gcode
SET_GCODE_VARIABLE MACRO=<name> VARIABLE=<var> VALUE=<val>
SET_DISPLAY_TEXT MSG="<text>"   # display on KlipperScreen/display

SET_INPUT_SHAPER SHAPER_FREQ_X=<> SHAPER_FREQ_Y=<> SHAPER_TYPE_X=<> SHAPER_TYPE_Y=<>
SET_PRESSURE_ADVANCE ADVANCE=<> [EXTRUDER=<name>] [SMOOTH_TIME=<>]
SET_FAN_SPEED FAN=<name> SPEED=<0.0-1.0>
SET_PIN PIN=<name> VALUE=<0.0-1.0>

DUMP_TMC STEPPER=<name>
SET_TMC_CURRENT STEPPER=<name> CURRENT=<amps>
INIT_TMC STEPPER=<name>
AUTOTUNE_TMC STEPPER=<name>     # klipper_tmc_autotune plugin

QUAD_GANTRY_LEVEL
BED_MESH_CALIBRATE [ADAPTIVE=1] [RUNS=<n>]
BED_MESH_CLEAR
BED_MESH_PROFILE LOAD=<name>

PROBE_ACCURACY [SAMPLES=<n>]
```

# Klipper Hardware Sensors: Eddy Current Probe + Load Cells + Filament Width Sensors
*Sources: klipper3d.org Eddy_Probe.html, Load_Cell.html, TSL1401CL_Filament_Width_Sensor.html, Hall_Filament_Width_Sensor.html — Full official documentation*
*Eddy + Load Cell are directly relevant background to Beacon (eddy-current + contact). None currently installed on Voronica, but Beacon's contact mode shares load-cell-probe concepts and its proximity mode shares eddy-current concepts.*

═══════════════════════════════════════════════════════════════
# EDDY CURRENT INDUCTIVE PROBE
═══════════════════════════════════════════════════════════════
*Background for Beacon — Beacon is an eddy-current scanner. These are the native-Klipper [probe_eddy_current] concepts; Beacon uses its own plugin (see DOC_BEACON3D.md) but the physics and probing methods are analogous.*

## How It Works
Eddy current probes detect the bed by measuring the RESONANT FREQUENCY of a coil. The closer the coil is to a metal bed, the higher the resonant frequency. Frequency → distance estimate.

## Four Probing Methods (via METHOD= parameter)

### Default (bare `PROBE`)
Toolhead descends until the sensor detects it's near the bed, then takes several measurements at the halted position. Most general purpose, good precision and flexibility. Works from many starting positions (just keep the sensor over metal bed).
- **Disadvantage:** Subject to thermal drift (microns). Run calibration and probing at consistent temperature.
- **Use for:** QUAD_GANTRY_LEVEL, Z_TILT_ADJUST, SCREWS_TILT_CALCULATE, DELTA_CALIBRATE.

### "scan" (`PROBE METHOD=scan` / `BED_MESH_CALIBRATE METHOD=scan`)
Probe does NOT descend — gathers measurements at current Z while moving horizontally. Entire bed scanned with horizontal moves only.
- **Advantages:** No Z change → less backlash impact; good for relative Z (zero_reference_position); faster than default.
- **Disadvantages:** Bed must be nearly parallel to XY rails with no large height deviations. Requires low HORIZONTAL_MOVE_Z (nozzle ≤~1mm from bed) — risk of collision on deviated beds. Same thermal drift.
- **Use for:** Bed mesh. Verify bed parallel first (e.g. `QUAD_GANTRY_LEVEL RETRY_TOLERANCE=0.250`), then `BED_MESH_CALIBRATE METHOD=scan HORIZONTAL_MOVE_Z=1`.

### "rapid_scan" (`BED_MESH_CALIBRATE METHOD=rapid_scan`)
Like scan but doesn't pause at each point — measures during continuous horizontal movement.
- Slightly faster than scan, but LESS accurate. Same parallel-bed and thermal-drift requirements.
- **Use for:** Large diagnostic bed meshes where speed > accuracy. Normal printing prefers regular "scan".

### "tap" (`PROBE METHOD=tap`)
Toolhead descends until the NOZZLE contacts the bed, then lifts; sensor measurements during lift determine where the nozzle breaks contact.
- **Advantages:** Results based on actual nozzle-bed contact (accounts for nozzle geometry — good if you change nozzles). NO thermal drift (main calibration not used). Axis twist less of an issue (no XY probe offset).
- **Disadvantages:** Nozzle AND bed must be clean (debris skews results). Nozzle must start 3-20mm from bed (too close → missed contact → crash; too far → inaccurate). Hardware must allow nozzle to fully contact bed (no limit switches stopping first). Nozzle temp must not be too high for the bed (could melt PEI).
- **Use for:** One step in a multi-step homing/leveling macro to account for nozzle geometry and reduce thermal drift.

## Configuration
Declare `[probe_eddy_current my_eddy_probe]`. Set `descend_z: 0.5`. Usually needs x_offset/y_offset (estimate during initial calibration if unknown).

### Calibrate Drive Current (first)
Home, position sensor near bed center ~20mm above bed:
```
LDC_CALIBRATE_DRIVE_CURRENT CHIP=my_eddy_probe
```
Then `SAVE_CONFIG` and restart.

### Calibrate Z Heights (second)
Home, nozzle near bed center:
```
PROBE_EDDY_CURRENT_CALIBRATE CHIP=my_eddy_probe
```
Follow paper test, `ACCEPT`. Tool correlates sensor readings to Z (takes a couple minutes), outputs noise/MAD data per Z height. Then `SAVE_CONFIG`. Verify x_offset/y_offset afterward; if changed, re-run PROBE_EDDY_CURRENT_CALIBRATE. Thermal drift: calibrate and probe at the same temperature.

### Tap Calibration
Requires `position_min: -1` in [stepper_z] (so nozzle can be commanded below bed plane to ensure contact). Configure `tap_threshold` (too large → missed contact → crash; too small → premature halt → errors). Use:
```
PROBE_EDDY_CURRENT_TAP_CALIBRATE TAP=guess
```
Verify nozzle+bed clean, nozzle 3-10mm from bed, be ready with `M112`. The command makes an initial coarse tap_threshold guess from the main calibration, then performs a tap.

## Thermal Drift
Eddy sensors are susceptible to thermal drift — temperature changes (bed surface, sensor hardware, nearby metal) change reported Z. Calibrate and probe at the same temperature. (Native [temperature_probe] section supports drift compensation — see DOC_KLIPPER_CONFIG_REFERENCE.md.)

═══════════════════════════════════════════════════════════════
# LOAD CELLS
═══════════════════════════════════════════════════════════════
*Background for Beacon CONTACT mode and toolhead force probes. A calibrated force sensor is the core of a load-cell-based probe.*

## LOAD_CELL_DIAGNOSTIC
Run when first connecting a load cell — collects 10s of data:
```
LOAD_CELL_DIAGNOSTIC
// Samples Collected: 3211
// Measured samples per second: 332.0
// Good samples: 3211, Saturated samples: 0, Unique values: 900
// Sample range: [4.01% to 4.02%]
```
Checks:
- Measured samples/sec should match configured sample rate (else config/wiring issue).
- Saturated samples should be 0 (else seeing more force than measurable).
- Unique values should be a large % of samples collected (Unique=1 → likely wiring issue).
- Tap/push the sensor during the test → Sample range should increase.

## LOAD_CELL_CALIBRATE (3-step interactive)
1. `TARE` — establishes zero force (reference_tare_counts).
2. Apply a known load, run `CALIBRATE GRAMS=nnn` — calculates counts_per_gram.
3. `ACCEPT` to save. (`ABORT` to cancel.)

**Applying known force:** Under-platform cells → put a known mass (e.g. 1kg filament spools). Toolhead cells → put a digital scale on the bed and lower the toolhead onto it (FORCE_MOVE or manual Z with motors off). Ideal calibration force is a large % of rated capacity (e.g. 5kg mass for a 5kg cell), but for toolhead probes use at least 1kg if the hardware can tolerate it. Verify reported Total capacity is close to the cell's theoretical rating.

## Reading Force
```
LOAD_CELL_READ          # // 10.6g (1.94%)
{% set grams = printer.load_cell.force_g %}   # 1-second average, in macro
```

## Taring
```
LOAD_CELL_TARE          # sets current weight to 0
{% set tare_counts = printer.load_cell.tare_counts %}
```

## Load Cell Probe Safety (direct nozzle-contact probe)
- **Calibration Check:** Every homing move verifies the cell is calibrated, else `!! Load Cell not calibrated`.
- **counts_per_gram:** Converts raw counts to grams; all safety limits are in grams. NEVER guess — use LOAD_CELL_CALIBRATE. Inaccurate value → can exceed safe toolhead force.
- **trigger_force:** Force (grams) that halts the homing move, measured from the tare taken at move start. Always some OVERSHOOT — be conservative (e.g. 100g setting can peak at 350g before stopping). Overshoot increases with faster probing speed, low ADC sample rate, or multi-MCU homing.

Supported ADC sensors (see config reference): HX711, HX717, ADS1220.

═══════════════════════════════════════════════════════════════
# FILAMENT WIDTH SENSORS (brief)
═══════════════════════════════════════════════════════════════
*Not installed on Voronica. Summary for completeness.*

## TSL1401CL Filament Width Sensor
Optical sensor measuring filament width. Config `[tsl1401cl_filament_width_sensor]` with pin, default_nominal_filament_diameter (1.75), max_difference (0.2), measurement_delay (distance sensor→melt chamber). Adjusts extrusion in real time based on measured width.

## Hall Filament Width Sensor
Uses two Hall sensors (e.g. two magnets) to measure width on two axes. Config `[hall_filament_width_sensor]` with adc1, adc2 pins, cal_dia1/cal_dia2 (1.50/2.00), raw_dia1/raw_dia2 calibration, default_nominal_filament_diameter, max_difference (0.200), measurement_delay (sensor→hotend distance, FIFO logic). Can enable/disable flow compensation; triggers runout via virtual filament_switch_sensor. See DOC_KLIPPER_CONFIG_REFERENCE.md for full parameter list.

# Klipper Rotation Distance Guide
*Source: klipper3d.org/Rotation_Distance.html — Full official documentation*

---

## What is rotation_distance?

The amount of distance (mm) the axis travels with ONE FULL REVOLUTION of the stepper motor (or final gear if gear_ratio is specified).

---

## Method 1: Converting from steps_per_mm

If you know the old steps_per_mm value:
```
rotation_distance = full_steps_per_rotation * microsteps / steps_per_mm
```

If you know the old step_distance value:
```
rotation_distance = full_steps_per_rotation * microsteps * step_distance
```

- `full_steps_per_rotation`: 200 for 1.8° motors, 400 for 0.9° motors
- `microsteps`: from driver config (16 is common default)
- Round to nearest whole number if within 0.01 of a whole number

---

## Method 2: From Hardware Inspection

### Belt-driven axes (X, Y on Voronica)
```
rotation_distance = belt_pitch * number_of_teeth_on_pulley
```
Example: 2mm belt pitch, 20-tooth pulley → rotation_distance = 40

**Voronica X/Y:** 2GT belt (2mm pitch), 20-tooth pulleys → rotation_distance: 40 ✓

### Lead screw axes (Z)
```
rotation_distance = screw_pitch * number_of_separate_threads
```
Common examples:
- T8 leadscrew: 2mm pitch × 4 threads = 8
- M6 threaded rod: 1mm pitch × 1 thread = 1
- M8 threaded rod: 1.25mm pitch × 1 thread = 1.25

**Voronica Z:** Uses 80:16 gear ratio with belt-driven lead system. rotation_distance: 40 with gear_ratio: 80:16 ✓

### Extruder (initial estimate)
```
rotation_distance = hobbed_bolt_diameter * 3.14
```
Then calibrate with measure-and-trim procedure below.

**Voronica extruder:** rotation_distance: 22.6789511 with gear_ratio: 50:6 (confirmed calibrated) ✓

---

## Method 3: Calibrating Extruder with Measure-and-Trim

**IMPORTANT: Only use this method for extruders. Do NOT use for X, Y, Z axes.**

1. Ensure filament is loaded, hotend heated, printer ready to extrude
2. Mark filament ~70mm from extruder body intake. Measure exact distance — note as `initial_mark_distance`
3. Extrude 50mm slowly:
   ```
   G91
   G1 E50 F60
   ```
   (Use slow rate F60 = 1mm/s to avoid pressure skewing results)
4. Measure new distance from extruder body to mark — note as `subsequent_mark_distance`
5. Calculate: `actual_extrude_distance = initial_mark_distance - subsequent_mark_distance`
6. Calculate new rotation_distance:
   ```
   rotation_distance = previous_rotation_distance * actual_extrude_distance / requested_extrude_distance
   ```
   Round to 3 decimal places.

Repeat if actual differs from requested by more than ~2mm.

---

## Using gear_ratio

Set `gear_ratio` when the stepper is connected to the axis via a gearbox. The rotation_distance then represents distance with one rotation of the FINAL GEAR.

```
gear_ratio: 5:1      # 5:1 gearbox
gear_ratio: 80:16    # Voronica Z (belt and pulley count)
gear_ratio: 50:6     # Voronica extruder (WWBMG gears)
```

**Counting teeth for pulleys:**
If stepper has 16-tooth pulley driving 80-tooth pulley: `gear_ratio: 80:16`

**Multiple gearboxes:** comma-separated list:
```
gear_ratio: 5:1, 80:16
```

**Note on BMG-style extruders:** BMG advertises "3:1" but actually uses "50:17" gearing. Use actual tooth counts for accuracy.

**Planetary gearboxes:** "5.18:1 planetary" is more accurately `gear_ratio: 57:11`

---

## Quick Reference for Voronica

| Axis | rotation_distance | gear_ratio | Notes |
|---|---|---|---|
| stepper_x/y/x1/y1 | 40 | (none) | 2mm belt, 20T pulley |
| stepper_z/z1/z2/z3 | 40 | 80:16 | belt/pulley system |
| extruder | 22.6789511 | 50:6 | WWBMG, calibrated |

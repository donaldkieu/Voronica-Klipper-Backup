# Klipper: Axis Twist Compensation + Skew Correction + Exclude Objects + Multi-MCU Homing
*Sources: klipper3d.org Axis_Twist_Compensation.html, Skew_Correction.html, Exclude_Object.html, Multi_MCU_Homing.html — Full official documentation*

═══════════════════════════════════════════════════════════════
# AXIS TWIST COMPENSATION
═══════════════════════════════════════════════════════════════
*Voronica has this CONFIGURED: calibrate_start_x: 20, calibrate_end_x: 280, calibrate_y: 150 (nozzle coord; probe lands at Y=173)*

## What It Does
Corrects for a small twist in the X rail that skews probe results. Common on printers where the probe is on the X carriage (Prusa MK3, Sovol SV06 style). A twist causes Bed Mesh, Screws Tilt Adjust, Z Tilt Adjust etc. to return inaccurate bed representations. Uses manual user measurements to correct probe results.

**If the axis is significantly twisted, fix it mechanically FIRST before applying software correction.**

**Warning:** Not compatible with dockable probes — it will try to probe without attaching the probe.

## Basic Usage — X-Axis Calibration
Ensure probe X and Y offsets are correctly set first (they greatly influence calibration).
```
AXIS_TWIST_COMPENSATION_CALIBRATE
```
- Calibrates X-axis by default.
- Wizard prompts you to measure probe Z offset at several points along the bed (paper test at each).
- Default 3 points; change with `SAMPLE_COUNT=<value>`.

After completing:
1. Adjust your Z offset (re-run probe Z offset calibration).
2. Perform bed leveling operations (Screws Tilt Adjust, Z Tilt Adjust as applicable).
3. Home all axes, run Bed Mesh if needed, test print, fine-tune.

## Y-Axis Calibration
```
AXIS_TWIST_COMPENSATION_CALIBRATE AXIS=Y
```
Same measuring process as X. Note: bed/nozzle temperature and nozzle size do not appear to influence the calibration.

## Config & Commands
Config options: see DOC_KLIPPER_CONFIG_REFERENCE.md [axis_twist_compensation].
Key params (Voronica): calibrate_start_x, calibrate_end_x, calibrate_y (for X-twist); calibrate_start_y, calibrate_end_y, calibrate_x (for Y-twist).

═══════════════════════════════════════════════════════════════
# SKEW CORRECTION
═══════════════════════════════════════════════════════════════
*Voronica: NOT currently configured. Reference for dimensional-accuracy correction if needed.*

## What It Does
Software correction for dimensional inaccuracy from a printer assembly that is not perfectly square. **If significantly skewed, square the printer mechanically first.**

## Procedure
1. **Print a calibration object** along the plane to correct (Thingiverse 2563185 for single plane, 2972743 for all planes). Orient so corner A is toward the plane's origin. Print with NO skew correction active — remove `[skew_correction]` or issue `SET_SKEW CLEAR=1`.

2. **Take 3 measurements per plane:**
   - Length AC (corner A to corner C)
   - Length BD (corner B to corner D)
   - Length AD (corner A to corner D — do NOT include corner flats)

3. **Configure** with `[skew_correction]` in printer.cfg, then:
   ```
   SET_SKEW XY=140.4,142.8,99.8
   ```
   Multiple planes:
   ```
   SET_SKEW XY=140.4,142.8,99.8 XZ=141.6,141.4,99.8 YZ=142.4,140.5,99.5
   ```

4. **Save as profile** (like bed_mesh):
   ```
   SKEW_PROFILE SAVE=my_skew_profile     # then SAVE_CONFIG
   SKEW_PROFILE LOAD=my_skew_profile
   SKEW_PROFILE REMOVE=my_skew_profile   # then SAVE_CONFIG
   ```

5. **Verify** — reprint with correction enabled, then:
   ```
   CALC_MEASURED_SKEW AC=<ac> BD=<bd> AD=<ad>
   ```
   Results should be lower than `GET_CURRENT_SKEW` reported before.

## Caveats
- Configure skew in START_PRINT gcode AFTER homing and after any move near the print-area edge (purge/wipe). Use `SET_SKEW` or `SKEW_PROFILE`.
- Add `SET_SKEW CLEAR=1` to END_PRINT gcode.
- Skew correction can move the tool beyond X/Y boundaries — keep parts away from bed edges when using it.

═══════════════════════════════════════════════════════════════
# EXCLUDE OBJECTS
═══════════════════════════════════════════════════════════════
*Voronica uses KAMP, which works with [exclude_object]. Enables cancelling individual objects mid-print.*

## Setup
Include `[exclude_object]` config section. The gcode file must be PRE-PROCESSED to add exclude_object markers (OrcaSlicer can label objects natively; otherwise use middleware or the cancelobject-preprocessor script). This processing does not fit Klipper's core design, so it happens before gcode reaches Klipper.

## Object Definitions
`EXCLUDE_OBJECT_DEFINE` summarizes each object so the UI doesn't have to parse the whole file:
```
EXCLUDE_OBJECT_DEFINE NAME=calibration_pyramid CENTER=50,50 POLYGON=[[40,40],[50,60],[60,40]]
```
- NAME: object identifier (lets users select what to cancel).
- CENTER: X,Y coordinate.
- POLYGON: json-compatible array of [X,Y] tuples without whitespace (bounding box or detailed hull).

## Key Commands
```
EXCLUDE_OBJECT_DEFINE NAME=<name> CENTER=<x,y> POLYGON=<...>   # define object
EXCLUDE_OBJECT_START NAME=<name>     # mark start of object's gcode
EXCLUDE_OBJECT_END                   # mark end
EXCLUDE_OBJECT NAME=<name>           # exclude/cancel an object
EXCLUDE_OBJECT_DEFINE RESET=1        # reset definitions
```

## Status (for macros/UI)
```
printer.exclude_object.objects            # all defined objects (name, center, polygon)
printer.exclude_object.excluded_objects   # list of excluded object names
printer.exclude_object.current_object     # object currently being printed
```
Status resets on: firmware restart, virtual_sdcard reset (start of print), or `EXCLUDE_OBJECT_DEFINE RESET=1`. Because Klipper looks ahead in gcode, there may be a delay between an EXCLUDE_OBJECT command and the status update.

═══════════════════════════════════════════════════════════════
# MULTI-MCU HOMING AND PROBING
═══════════════════════════════════════════════════════════════
*Relevant to Voronica: Beacon probe and EBBCan endstops are on different MCUs than the Z/XY steppers (Manta M8P).*

## What It Is
Homing with an endstop on one MCU while its stepper motors are on a different MCU. Also used when a Z probe is on a different MCU than the Z steppers — exactly Voronica's case (Beacon on USB, steppers on Manta M8P).

## Overshoot Behavior
Message transmission delay between the endstop MCU and the stepper MCU causes possible stepper "overshoot" during homing/probing. Klipper limits this delay to ≤25ms (MCUs exchange periodic status messages and check they arrive within 25ms).

Overshoot example: homing at 10mm/s → up to 0.250mm overshoot (10mm/s × 0.025s). Use slower homing/probing speeds to reduce it. The hardware must tolerate overshoot without damage.

**Klipper detects and accounts for overshoot in its calculations**, so precision is not adversely affected — but the mechanical design must handle the physical overshoot.

## Latency Requirements
- Round-trip time between host and ALL MCUs must be consistently < 10ms.
- High latency (even briefly) → homing failures.
- On failure or other comms issue: `Communication timeout during homing` error.

## Important Constraint
An axis with multiple steppers (e.g. stepper_z and stepper_z1) must have ALL its steppers on the SAME MCU to use multi-mcu homing. If an endstop is on a separate MCU from stepper_z, then stepper_z1 must be on the same MCU as stepper_z.

**Voronica:** All 4 Z steppers are on the Manta M8P (same MCU), Beacon is on USB — this satisfies the constraint. Beacon contact/proximity probing operates as multi-mcu probing.

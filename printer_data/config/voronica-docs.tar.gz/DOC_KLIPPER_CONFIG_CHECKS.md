# Klipper Configuration Checks Guide
*Source: klipper3d.org/Config_checks.html — Full official documentation*
*Pin-verification steps to run after install or after wiring/hardware changes. RESTART after every config change; STATUS to confirm load.*

---

## 1. Verify Temperature
Check the temperature graph: nozzle and bed temps should be present and NOT increasing on their own. If increasing → remove power immediately. If inaccurate → review `sensor_type` and `sensor_pin` for the affected heater.

## 2. Verify M112 (Emergency Stop)
Issue `M112` in the console → Klipper enters "shutdown" state and shows an error. Clear with `FIRMWARE_RESTART` (and reconnect the UI). Then confirm temps still update and are not climbing. If climbing → remove power.

## 3. Verify Heaters
In the temperature box, command the extruder to 50°C. Temp should begin rising within ~30s. Then set to "Off" — temp should fall back to room temp over several minutes. If it does not rise → verify `heater_pin`. Repeat for the heated bed.

## 4. Verify Stepper Motor Enable Pin
All axes should move freely by hand (steppers disabled). If not, issue `M84`. If an axis still won't move freely → verify the stepper `enable_pin`. Most commodity drivers are "active low", so the enable pin needs a `!` prefix (e.g. `enable_pin: !PA1`).

## 5. Verify Endstops
Move all axes clear of endstops. Run `QUERY_ENDSTOPS` → all should report "open". Re-run while manually triggering each endstop → should report "TRIGGERED".
- **Inverted** (open when triggered): add or remove `!` on the pin (e.g. `endstop_pin: ^!PA2`).
- **No change at all**: usually the endstop is on a different pin. May also need a pullup change — the `^` prefix. Most printers use a pullup, so `^` should be present.

## 6. Verify Stepper Motors (STEPPER_BUZZ)
Position the axis at a midpoint, then run:
```
STEPPER_BUZZ STEPPER=stepper_x
```
The stepper moves 1mm positive, returns, and oscillates 10 times.
- **No movement** → verify `enable_pin` and `step_pin`.
- **Moves but doesn't return to start** → verify `dir_pin`.
- **Oscillates in wrong direction** → invert `dir_pin` (add/remove `!`).
- **Moves much more/less than 1mm** → verify `rotation_distance`.

Run for each stepper (set STEPPER= to the config section name). After all endstops and steppers verify, test homing with `G28`. Remove power if it doesn't home properly.

**Voronica steppers to buzz:** stepper_x, stepper_y, stepper_x1, stepper_y1, stepper_z, stepper_z1, stepper_z2, stepper_z3, extruder.

## 7. Verify Extruder Motor
Heat the extruder to printing temp first (min_extrude_temp gate). Then click "Extrude" and verify the motor turns the correct direction. If wrong → check `enable_pin`, `step_pin`, `dir_pin` for the extruder.

## 8. Calibrate PID Settings
Klipper PID values from other firmware/example configs often work poorly — calibrate per printer.
```
PID_CALIBRATE HEATER=extruder TARGET=170
PID_CALIBRATE HEATER=heater_bed TARGET=60
```
Run `SAVE_CONFIG` after each to write the new PID values. Use PID for the bed only if it's PWM-driven (PID may switch the heater ~10×/second, unsuitable for mechanical-relay beds).

**Voronica calibrated values** (already done — see VORONICA_TUNING_STATE.md):
- Extruder PID @ 290°C: Kp 19.248 / Ki 1.181 / Kd 78.433
- Bed PID @ 110°C: Kp 68.581 / Ki 2.284 / Kd 514.789

## Next Steps
After basic verification: read the Bed Leveling guide, configure the slicer, then calibrate Pressure Advance. For ringing, follow Resonance Compensation tuning.
